package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.localization.formatBytes
import com.example.localization.formatSpeed
import com.example.model.FileCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("BH Downloader", appName)
  }

  @Test
  fun `file category detection`() {
    assertEquals(FileCategory.VIDEO, FileCategory.fromFileName("movie.mp4"))
    assertEquals(FileCategory.AUDIO, FileCategory.fromFileName("song.mp3"))
    assertEquals(FileCategory.IMAGE, FileCategory.fromFileName("photo.png"))
    assertEquals(FileCategory.DOCUMENT, FileCategory.fromFileName("report.pdf"))
    assertEquals(FileCategory.ARCHIVE, FileCategory.fromFileName("game.apk"))
    assertEquals(FileCategory.ARCHIVE, FileCategory.fromFileName("bundle.zip"))
  }

  @Test
  fun `formatting byte sizes and speed`() {
    assertEquals("0 B", formatBytes(0))
    assertTrue(formatBytes(1024).contains("1.00 KB"))
    assertTrue(formatBytes(1024 * 1024 * 5).contains("5.00 MB"))
    assertTrue(formatSpeed(1024 * 500).contains("KB/s"))
  }

  @Test
  fun `multilanguage localization verification`() {
    assertEquals("BH Downloader", AppStrings.appName(AppLanguage.DARI))
    assertEquals("همه", AppStrings.tabAll(AppLanguage.DARI))
    assertEquals("ټول", AppStrings.tabAll(AppLanguage.PASHTO))
    assertEquals("الكل", AppStrings.tabAll(AppLanguage.ARABIC))
    assertEquals("All", AppStrings.tabAll(AppLanguage.ENGLISH))
  }
}
