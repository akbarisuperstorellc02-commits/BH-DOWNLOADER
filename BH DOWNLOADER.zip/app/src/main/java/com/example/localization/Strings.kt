package com.example.localization

import java.util.Locale

object AppStrings {
    fun appName(lang: AppLanguage) = "BH Downloader"

    fun tagLine(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "دانلودر فوق‌سریع و هوشمند چندرشته‌ای"
        AppLanguage.PASHTO -> "چټک او هوښیار ملټي-تار ډاونلوډر"
        AppLanguage.ARABIC -> "مدير التنزيلات فائق السرعة ومتعدد المسارات"
        AppLanguage.ENGLISH -> "Ultra-fast Multi-threaded Download Manager"
    }

    // Tabs
    fun tabAll(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "همه"
        AppLanguage.PASHTO -> "ټول"
        AppLanguage.ARABIC -> "الكل"
        AppLanguage.ENGLISH -> "All"
    }

    fun tabDownloading(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "در حال دانلود"
        AppLanguage.PASHTO -> "کښته کیږي"
        AppLanguage.ARABIC -> "قيد التنزيل"
        AppLanguage.ENGLISH -> "Downloading"
    }

    fun tabCompleted(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تکمیل شده"
        AppLanguage.PASHTO -> "بشپړ شوي"
        AppLanguage.ARABIC -> "المكتملة"
        AppLanguage.ENGLISH -> "Completed"
    }

    fun tabCategories(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "دسته‌بندی‌ها"
        AppLanguage.PASHTO -> "کټګورۍ"
        AppLanguage.ARABIC -> "التصنيفات"
        AppLanguage.ENGLISH -> "Categories"
    }

    fun tabBrowser(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "مرورگر و تست"
        AppLanguage.PASHTO -> "براوزر او ټیسټ"
        AppLanguage.ARABIC -> "المتصفح وروابط"
        AppLanguage.ENGLISH -> "Browser & Tests"
    }

    fun tabThroughput(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "نمودار ۳D سرعت"
        AppLanguage.PASHTO -> "۳D د چټکتیا ګراف"
        AppLanguage.ARABIC -> "رسم بياني 3D"
        AppLanguage.ENGLISH -> "3D Speed Graph"
    }

    fun realtimeThroughputTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "پایش بلادرنگ پهنای باند و سرعت ۳D"
        AppLanguage.PASHTO -> "په ژوندۍ بڼه د بانډوایډ او چټکتیا څارنه"
        AppLanguage.ARABIC -> "مراقبة معدل نقل البيانات اللحظي"
        AppLanguage.ENGLISH -> "Real-Time 3D Network Throughput"
    }

    fun view3DMode(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "نمای سه‌بعدی (3D Cyber)"
        AppLanguage.PASHTO -> "۳D لید (3D Cyber)"
        AppLanguage.ARABIC -> "منظور 3D ثلاثي الأبعاد"
        AppLanguage.ENGLISH -> "3D Cyber Mode"
    }

    fun view2DMode(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "نمای دوبعدی (2D Wave)"
        AppLanguage.PASHTO -> "۲D څپیز لید (2D Wave)"
        AppLanguage.ARABIC -> "مخطط 2D تقليدي"
        AppLanguage.ENGLISH -> "2D Wave Mode"
    }

    fun currentSpeedLabel(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "سرعت لحظه‌ای"
        AppLanguage.PASHTO -> "اوسنۍ چټکتیا"
        AppLanguage.ARABIC -> "السرعة الحالية"
        AppLanguage.ENGLISH -> "Current Speed"
    }

    fun peakSpeedLabel(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "اوج سرعت (Peak)"
        AppLanguage.PASHTO -> "لوړه چټکتیا (Peak)"
        AppLanguage.ARABIC -> "أعلى سرعة"
        AppLanguage.ENGLISH -> "Peak Speed"
    }

    fun averageSpeedLabel(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "میانگین سرعت"
        AppLanguage.PASHTO -> "منځنۍ چټکتیا"
        AppLanguage.ARABIC -> "متوسط السرعة"
        AppLanguage.ENGLISH -> "Avg Speed"
    }

    fun activeConnectionsLabel(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "رشته‌های فعال توربو"
        AppLanguage.PASHTO -> "فعالې اړیکې"
        AppLanguage.ARABIC -> "المسارات النشطة"
        AppLanguage.ENGLISH -> "Active Turbo Streams"
    }

    fun tiltControlsLabel(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "زاویه چرخش سه‌بعدی"
        AppLanguage.PASHTO -> "د ۳D تاوېدل"
        AppLanguage.ARABIC -> "زاوية المنظور 3D"
        AppLanguage.ENGLISH -> "3D Perspective Tilt"
    }

    // Categories
    fun catVideos(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "ویدیوها"
        AppLanguage.PASHTO -> "ویډیوګانې"
        AppLanguage.ARABIC -> "فيديوهات"
        AppLanguage.ENGLISH -> "Videos"
    }

    fun catMusic(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "موسیقی و صدا"
        AppLanguage.PASHTO -> "موسیقي او غږ"
        AppLanguage.ARABIC -> "موسيقى وصوتيات"
        AppLanguage.ENGLISH -> "Music & Audio"
    }

    fun catImages(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تصاویر"
        AppLanguage.PASHTO -> "انځورونه"
        AppLanguage.ARABIC -> "الصور"
        AppLanguage.ENGLISH -> "Images"
    }

    fun catDocuments(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "اسناد و کتب"
        AppLanguage.PASHTO -> "اسناد او کتابونه"
        AppLanguage.ARABIC -> "المستندات"
        AppLanguage.ENGLISH -> "Documents"
    }

    fun catArchives(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "فشرده و برنامه‌ها"
        AppLanguage.PASHTO -> "آرشیف او پروګرامونه"
        AppLanguage.ARABIC -> "المضغوطة والتطبيقات"
        AppLanguage.ENGLISH -> "Archives & APK"
    }

    fun catOther(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "سایر فایل‌ها"
        AppLanguage.PASHTO -> "نور فایلونه"
        AppLanguage.ARABIC -> "ملفات أخرى"
        AppLanguage.ENGLISH -> "Other Files"
    }

    // Actions
    fun addDownload(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "افزودن دانلود"
        AppLanguage.PASHTO -> "ډاونلوډ ورزیات کړئ"
        AppLanguage.ARABIC -> "إضافة تنزيل"
        AppLanguage.ENGLISH -> "Add Download"
    }

    fun pause(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "توقف"
        AppLanguage.PASHTO -> "ودروئ"
        AppLanguage.ARABIC -> "إيقاف مؤقت"
        AppLanguage.ENGLISH -> "Pause"
    }

    fun resume(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "ادامه"
        AppLanguage.PASHTO -> "دوام ورکړئ"
        AppLanguage.ARABIC -> "استئناف"
        AppLanguage.ENGLISH -> "Resume"
    }

    fun pauseAll(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "توقف همه"
        AppLanguage.PASHTO -> "ټول ودروئ"
        AppLanguage.ARABIC -> "إيقاف الكل"
        AppLanguage.ENGLISH -> "Pause All"
    }

    fun resumeAll(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "ادامه همه"
        AppLanguage.PASHTO -> "ټول پیل کړئ"
        AppLanguage.ARABIC -> "استئناف الكل"
        AppLanguage.ENGLISH -> "Resume All"
    }

    fun clearCompleted(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "پاکسازی تکمیل‌شده‌ها"
        AppLanguage.PASHTO -> "بشپړ شوي پاک کړئ"
        AppLanguage.ARABIC -> "مسح المكتملة"
        AppLanguage.ENGLISH -> "Clear Completed"
    }

    fun openFile(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "باز کردن فایل"
        AppLanguage.PASHTO -> "فایل خلاص کړئ"
        AppLanguage.ARABIC -> "فتح الملف"
        AppLanguage.ENGLISH -> "Open File"
    }

    fun shareFile(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "اشتراک‌گذاری"
        AppLanguage.PASHTO -> "شریکول"
        AppLanguage.ARABIC -> "مشاركة"
        AppLanguage.ENGLISH -> "Share"
    }

    fun details(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "جزئیات و مشخصات"
        AppLanguage.PASHTO -> "تفصیلات او ځانګړنې"
        AppLanguage.ARABIC -> "التفاصيل"
        AppLanguage.ENGLISH -> "Details & Info"
    }

    fun delete(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "حذف"
        AppLanguage.PASHTO -> "ړنګول"
        AppLanguage.ARABIC -> "حذف"
        AppLanguage.ENGLISH -> "Delete"
    }

    fun cancel(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "لغو"
        AppLanguage.PASHTO -> "لغوه کول"
        AppLanguage.ARABIC -> "إلغاء"
        AppLanguage.ENGLISH -> "Cancel"
    }

    fun startDownload(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "شروع دانلود"
        AppLanguage.PASHTO -> "ډاونلوډ پیل کړئ"
        AppLanguage.ARABIC -> "بدء التنزيل"
        AppLanguage.ENGLISH -> "Start Download"
    }

    fun addPaused(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "افزودن در حالت متوقف"
        AppLanguage.PASHTO -> "په درېدلي حالت کې اضافه کول"
        AppLanguage.ARABIC -> "إضافة كمتوقف"
        AppLanguage.ENGLISH -> "Add as Paused"
    }

    // Dialog fields
    fun enterUrl(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "آدرس دانلود (URL)"
        AppLanguage.PASHTO -> "د کښته کولو لینک (URL)"
        AppLanguage.ARABIC -> "رابط التحميل (URL)"
        AppLanguage.ENGLISH -> "Download URL"
    }

    fun fileName(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "نام فایل"
        AppLanguage.PASHTO -> "د فایل نوم"
        AppLanguage.ARABIC -> "اسم الملف"
        AppLanguage.ENGLISH -> "File Name"
    }

    fun threadCount(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تعداد رشته‌های دانلود (سرعت توربو)"
        AppLanguage.PASHTO -> "د اړیکو شمېر (توربو سرعت)"
        AppLanguage.ARABIC -> "عدد المسارات المتزامنة (سرعة توربو)"
        AppLanguage.ENGLISH -> "Download Threads (Turbo Speed)"
    }

    fun threadsDescription(lang: AppLanguage, count: Int) = when (lang) {
        AppLanguage.DARI -> "$count رشته همزمان (تقسیم فایل به $count بخش پرسرعت)"
        AppLanguage.PASHTO -> "$count موازي اړیکې (فایل په $count برخو ویشل کیږي)"
        AppLanguage.ARABIC -> "$count مسارات متوازية (تقسيم الملف إلى $count أجزاء)"
        AppLanguage.ENGLISH -> "$count concurrent threads (splitting into $count turbo parts)"
    }

    fun selectCategory(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "دسته‌بندی فایل"
        AppLanguage.PASHTO -> "د فایل کټګوري"
        AppLanguage.ARABIC -> "تصنيف الملف"
        AppLanguage.ENGLISH -> "Category"
    }

    fun customHeaders(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تنظیمات پیشرفته (User-Agent و هدر)"
        AppLanguage.PASHTO -> "پرمختللي ترتیبات (User-Agent او هیډر)"
        AppLanguage.ARABIC -> "إعدادات متقدمة (User-Agent وترويسات)"
        AppLanguage.ENGLISH -> "Advanced Headers (User-Agent, Referer)"
    }

    // Statuses
    fun statusQueued(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "در صف"
        AppLanguage.PASHTO -> "په کتار کې"
        AppLanguage.ARABIC -> "في الانتظار"
        AppLanguage.ENGLISH -> "In Queue"
    }

    fun statusDownloading(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "در حال دریافت"
        AppLanguage.PASHTO -> "کښته کیږي"
        AppLanguage.ARABIC -> "جارٍ التنزيل"
        AppLanguage.ENGLISH -> "Downloading"
    }

    fun statusPaused(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "متوقف شده"
        AppLanguage.PASHTO -> "ودرول شو"
        AppLanguage.ARABIC -> "متوقف مؤقتاً"
        AppLanguage.ENGLISH -> "Paused"
    }

    fun statusCompleted(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تکمیل شد"
        AppLanguage.PASHTO -> "بشپړ شو"
        AppLanguage.ARABIC -> "اكتمل"
        AppLanguage.ENGLISH -> "Completed"
    }

    fun statusFailed(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "خطا در دانلود"
        AppLanguage.PASHTO -> "تېروتنه رامنځته شوه"
        AppLanguage.ARABIC -> "فشل التنزيل"
        AppLanguage.ENGLISH -> "Failed"
    }

    // Settings
    fun settings(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تنظیمات"
        AppLanguage.PASHTO -> "ترتیبات"
        AppLanguage.ARABIC -> "الإعدادات"
        AppLanguage.ENGLISH -> "Settings"
    }

    fun language(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "زبان برنامه"
        AppLanguage.PASHTO -> "د اپلیکیشن ژبه"
        AppLanguage.ARABIC -> "لغة التطبيق"
        AppLanguage.ENGLISH -> "Language"
    }

    fun theme(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "پوسته و تم"
        AppLanguage.PASHTO -> "رنګ او بڼه (تم)"
        AppLanguage.ARABIC -> "المظهر والسمة"
        AppLanguage.ENGLISH -> "Theme"
    }

    fun themeDark(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "حالت تاریک (Dark Mode)"
        AppLanguage.PASHTO -> "تیاره حالت (Dark Mode)"
        AppLanguage.ARABIC -> "الوضع الداكن"
        AppLanguage.ENGLISH -> "Dark Mode"
    }

    fun themeLight(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "حالت روشن (Light Mode)"
        AppLanguage.PASHTO -> "روښانه حالت (Light Mode)"
        AppLanguage.ARABIC -> "الوضع الفاتح"
        AppLanguage.ENGLISH -> "Light Mode"
    }

    fun themeSystem(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "پیروی از سیستم"
        AppLanguage.PASHTO -> "د سیسټم تابع"
        AppLanguage.ARABIC -> "تلقائي حسب النظام"
        AppLanguage.ENGLISH -> "System Default"
    }

    fun maxConcurrent(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "حداکثر دانلودهای همزمان"
        AppLanguage.PASHTO -> "په یو وخت د کښته کیدو حد"
        AppLanguage.ARABIC -> "الحد الأقصى للتنزيلات المتزامنة"
        AppLanguage.ENGLISH -> "Max Concurrent Downloads"
    }

    fun defaultThreads(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "تعداد پیش‌فرض رشته‌ها در هر دانلود"
        AppLanguage.PASHTO -> "د هر ډاونلوډ لپاره لومړني تارونه"
        AppLanguage.ARABIC -> "المسارات الافتراضية لكل تنزيل"
        AppLanguage.ENGLISH -> "Default Threads per Download"
    }

    fun clipboardDetect(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "شناسایی خودکار لینک از کلیپ‌بورد"
        AppLanguage.PASHTO -> "له کلیپ‌بورډ څخه د لینک اتومات پېژندل"
        AppLanguage.ARABIC -> "الكشف التلقائي عن الروابط المنسوخة"
        AppLanguage.ENGLISH -> "Auto-detect Links from Clipboard"
    }

    fun clipboardFoundTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "لینک دانلود در کلیپ‌بورد پیدا شد!"
        AppLanguage.PASHTO -> "په حافظه (کلیپ‌بورډ) کې لینک وموندل شو!"
        AppLanguage.ARABIC -> "تم العثور على رابط تنزيل منسوخ!"
        AppLanguage.ENGLISH -> "Download link detected in clipboard!"
    }

    fun emptyStateTitle(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "هیچ دانلودی موجود نیست"
        AppLanguage.PASHTO -> "کوم ډاونلوډ شتون نلري"
        AppLanguage.ARABIC -> "لا توجد تنزيلات حالياً"
        AppLanguage.ENGLISH -> "No downloads here"
    }

    fun emptyStateSubtitle(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "برای شروع، دکمه + را فشار دهید یا از بخش تست یکی از فایل‌ها را انتخاب کنید."
        AppLanguage.PASHTO -> "د پیل لپاره د + تڼۍ کېکاږئ یا له ټیسټ برخې فایل غوره کړئ."
        AppLanguage.ARABIC -> "اضغط على زر + لإضافة رابط أو جرّب أحد ملفات الاختبار السريعة."
        AppLanguage.ENGLISH -> "Tap the + button to add a URL or choose a fast test file to see turbo speed."
    }

    fun testFilesHeader(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "دانلودهای آزمایشی برای تست سرعت توربو"
        AppLanguage.PASHTO -> "د توربو چټکتیا آزموینې لپاره نمونوي فایلونه"
        AppLanguage.ARABIC -> "ملفات تجريبية لاختبار سرعة التوربو"
        AppLanguage.ENGLISH -> "Test Files for Turbo Speed Benchmark"
    }

    fun testFilesSubtitle(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "می‌توانید با یک ضربه قابلیت توقف/ادامه و سرعت چندرشته‌ای را آزمایش نمایید:"
        AppLanguage.PASHTO -> "تاسو کولی شئ په یو کلیک د څو اړیکو سرعت او بندول/دوام وازمویئ:"
        AppLanguage.ARABIC -> "بنقرة واحدة يمكنك اختبار تقسيم الأجزاء وسرعة الاستئناف الفوري:"
        AppLanguage.ENGLISH -> "Instantly test multi-threading, pause & resume with reliable public mirrors:"
    }

    fun calculateChecksum(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "محاسبه هش (MD5 / SHA-256)"
        AppLanguage.PASHTO -> "د هېش محاسبه (MD5 / SHA-256)"
        AppLanguage.ARABIC -> "حساب الرمز التعريفي (MD5 / SHA-256)"
        AppLanguage.ENGLISH -> "Calculate Checksum (MD5 / SHA-256)"
    }

    fun close(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "بستن"
        AppLanguage.PASHTO -> "بندول"
        AppLanguage.ARABIC -> "إغلاق"
        AppLanguage.ENGLISH -> "Close"
    }

    fun segmentsVisualizer(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "بخش‌های رشته‌ای (قطعات همزمان)"
        AppLanguage.PASHTO -> "د برخو پرمختګ (موازي ټوټې)"
        AppLanguage.ARABIC -> "أجزاء التنزيل المتزامنة"
        AppLanguage.ENGLISH -> "Segmented Turbo Threads"
    }

    fun supportsResume(lang: AppLanguage, yes: Boolean) = when (lang) {
        AppLanguage.DARI -> if (yes) "قابلیت ادامه: دارد (پشتیبانی از Range)" else "قابلیت ادامه: ندارد"
        AppLanguage.PASHTO -> if (yes) "د دوام ملاتړ: هو (د Range ملاتړ لري)" else "د دوام ملاتړ: نه"
        AppLanguage.ARABIC -> if (yes) "يدعم الاستئناف: نعم (Range مدعوم)" else "يدعم الاستئناف: لا"
        AppLanguage.ENGLISH -> if (yes) "Resume Support: Yes (Range enabled)" else "Resume Support: No"
    }

    fun copyUrl(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "کپی لینک"
        AppLanguage.PASHTO -> "لینک کاپي کړئ"
        AppLanguage.ARABIC -> "نسخ الرابط"
        AppLanguage.ENGLISH -> "Copy URL"
    }

    fun deleteConfirmMessage(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "آیا مطمئن هستید که می‌خواهید این دانلود را حذف کنید؟"
        AppLanguage.PASHTO -> "ایا ډاډه یاست چې دا ډاونلوډ ړنګول غواړئ؟"
        AppLanguage.ARABIC -> "هل أنت متأكد من رغبتك في حذف هذا التنزيل؟"
        AppLanguage.ENGLISH -> "Are you sure you want to delete this download?"
    }

    fun alsoDeleteFileFromDisk(lang: AppLanguage) = when (lang) {
        AppLanguage.DARI -> "فایل دانلود شده نیز از حافظه گوشی حذف شود"
        AppLanguage.PASHTO -> "کښته شوی فایل دې هم له حافظې پاک شي"
        AppLanguage.ARABIC -> "حذف الملف الفعلي من ذاكرة الهاتف أيضاً"
        AppLanguage.ENGLISH -> "Also delete downloaded file from storage"
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    val clampedGroup = digitGroups.coerceIn(0, units.size - 1)
    val value = bytes / Math.pow(1024.0, clampedGroup.toDouble())
    return String.format(Locale.US, "%.2f %s", value, units[clampedGroup])
}

fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0) return "0 KB/s"
    return "${formatBytes(bytesPerSec)}/s"
}

fun formatEta(seconds: Long, lang: AppLanguage): String {
    if (seconds <= 0 || seconds > 86400 * 7) {
        return when (lang) {
            AppLanguage.DARI -> "--:--"
            AppLanguage.PASHTO -> "--:--"
            AppLanguage.ARABIC -> "--:--"
            AppLanguage.ENGLISH -> "--:--"
        }
    }
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return if (hrs > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }
}
