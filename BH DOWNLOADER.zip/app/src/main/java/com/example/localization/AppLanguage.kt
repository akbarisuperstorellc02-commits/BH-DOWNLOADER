package com.example.localization

import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val layoutDirection: LayoutDirection
) {
    DARI("fa", "دری", "Dari (فارسی دری)", LayoutDirection.Rtl),
    PASHTO("ps", "پښتو", "Pashto (پښتو)", LayoutDirection.Rtl),
    ARABIC("ar", "العربية", "Arabic (العربية)", LayoutDirection.Rtl),
    ENGLISH("en", "English", "English", LayoutDirection.Ltr);

    val isRtl: Boolean
        get() = layoutDirection == LayoutDirection.Rtl
}
