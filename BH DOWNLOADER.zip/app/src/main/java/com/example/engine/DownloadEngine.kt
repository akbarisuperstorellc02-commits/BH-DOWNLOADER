package com.example.engine

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.DownloadRepository
import com.example.model.DownloadChunk
import com.example.model.DownloadStatus
import com.example.model.DownloadTask
import com.example.model.FileCategory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min

class DownloadEngine private constructor(
    private val context: Context,
    private val repository: DownloadRepository
) {
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<Long, Job>()
    private val speedTrackers = ConcurrentHashMap<Long, SpeedTracker>()

    private val _engineEvents = MutableSharedFlow<EngineEvent>()
    val engineEvents = _engineEvents.asSharedFlow()

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
        .retryOnConnectionFailure(true)
        .build()

    var maxConcurrentDownloads: Int = 3

    sealed class EngineEvent {
        data class TaskStarted(val taskId: Long) : EngineEvent()
        data class TaskProgress(val taskId: Long, val downloaded: Long, val total: Long, val speed: Long) : EngineEvent()
        data class TaskPaused(val taskId: Long) : EngineEvent()
        data class TaskCompleted(val taskId: Long, val file: File) : EngineEvent()
        data class TaskFailed(val taskId: Long, val error: String) : EngineEvent()
    }

    private class SpeedTracker {
        val lastBytes = AtomicLong(0L)
        var lastTimestamp = System.currentTimeMillis()
        var currentSpeed = 0L

        fun calculateSpeed(currentTotalDownloaded: Long): Long {
            val now = System.currentTimeMillis()
            val timeDiff = now - lastTimestamp
            if (timeDiff >= 700) {
                val previous = lastBytes.getAndSet(currentTotalDownloaded)
                val bytesDiff = (currentTotalDownloaded - previous).coerceAtLeast(0L)
                currentSpeed = if (timeDiff > 0) (bytesDiff * 1000L) / timeDiff else 0L
                lastTimestamp = now
            }
            return currentSpeed
        }
    }

    fun isTaskActive(taskId: Long): Boolean = activeJobs[taskId]?.isActive == true

    fun startOrResume(taskId: Long) {
        synchronized(activeJobs) {
            if (activeJobs[taskId]?.isActive == true) return

            val job = engineScope.launch {
                runDownloadPipeline(taskId)
            }
            activeJobs[taskId] = job
        }
    }

    fun pauseDownload(taskId: Long) {
        val job = activeJobs.remove(taskId)
        job?.cancel()
        engineScope.launch {
            val task = repository.getTaskById(taskId)
            if (task != null && task.status != DownloadStatus.COMPLETED) {
                repository.updateTask(task.copy(
                    status = DownloadStatus.PAUSED,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L
                ))
                _engineEvents.emit(EngineEvent.TaskPaused(taskId))
            }
        }
    }

    fun cancelDownload(taskId: Long, deleteFiles: Boolean = true) {
        val job = activeJobs.remove(taskId)
        job?.cancel()
        engineScope.launch {
            val task = repository.getTaskById(taskId)
            if (task != null) {
                repository.deleteTaskById(taskId)
                if (deleteFiles) {
                    try {
                        val file = File(task.filePath)
                        if (file.exists()) file.delete()
                        val tempDir = FileHelper.getTempDir(context, taskId)
                        if (tempDir.exists()) tempDir.deleteRecursively()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error cleaning files: ${e.message}")
                    }
                }
            }
        }
    }

    fun pauseAll() {
        val runningIds = activeJobs.keys.toList()
        for (id in runningIds) {
            pauseDownload(id)
        }
    }

    private fun applyStandardHeaders(builder: Request.Builder, url: String, customHeaders: String?) {
        builder.header("User-Agent", BROWSER_USER_AGENT)
        builder.header("Accept", "*/*")
        builder.header("Accept-Language", "en-US,en;q=0.9,fa;q=0.8,ar;q=0.7")
        builder.header("Accept-Encoding", "identity")
        builder.header("Connection", "keep-alive")
        try {
            val uri = Uri.parse(url)
            val scheme = uri.scheme ?: "https"
            val host = uri.host
            if (!host.isNullOrBlank()) {
                builder.header("Referer", "$scheme://$host/")
            }
        } catch (ignored: Exception) {}

        if (!customHeaders.isNullOrBlank()) {
            customHeaders.lines().forEach { line ->
                val parts = line.split(":", limit = 2)
                if (parts.size == 2) {
                    val key = parts[0].trim()
                    val value = parts[1].trim()
                    if (key.isNotBlank() && value.isNotBlank()) {
                        builder.header(key, value)
                    }
                }
            }
        }
    }

    data class TaskMetadata(
        val directUrl: String,
        val fileName: String,
        val totalBytes: Long,
        val supportsRanges: Boolean,
        val mimeType: String?,
        val category: FileCategory
    )

    suspend fun inspectUrl(
        url: String,
        customHeaders: Map<String, String> = emptyMap()
    ): TaskMetadata = withContext(Dispatchers.IO) {
        var directUrl = url.trim()
        var fileName = extractFileNameFromUrl(directUrl)
        var totalBytes = -1L
        var supportsRanges = false
        var mimeType: String? = null

        // Step 1: Probe with small range GET (bytes=0-1024) with full browser headers
        try {
            val reqBuilder = Request.Builder().url(directUrl)
            applyStandardHeaders(reqBuilder, directUrl, null)
            reqBuilder.header("Range", "bytes=0-1024")
            customHeaders.forEach { (k, v) -> reqBuilder.header(k, v) }

            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                if (response.isSuccessful || response.code == 206) {
                    mimeType = response.header("Content-Type")
                    val disposition = response.header("Content-Disposition")
                    val dispName = extractFileNameFromDisposition(disposition)
                    if (!dispName.isNullOrBlank()) fileName = dispName

                    if (response.code == 206) {
                        supportsRanges = true
                        val contentRange = response.header("Content-Range")
                        if (contentRange != null && contentRange.contains("/")) {
                            val totalPart = contentRange.substringAfterLast("/").trim()
                            totalBytes = totalPart.toLongOrNull() ?: totalBytes
                        }
                    } else {
                        totalBytes = response.header("Content-Length")?.toLongOrNull() ?: totalBytes
                    }

                    // Media Sniffer: If URL returns an HTML webpage, check for embedded direct video stream!
                    if (mimeType?.contains("text/html", ignoreCase = true) == true) {
                        val htmlBody = response.body?.string() ?: ""
                        val extractedVideoUrl = extractDirectMediaUrlFromHtml(htmlBody, directUrl)
                        if (!extractedVideoUrl.isNullOrBlank() && extractedVideoUrl != directUrl) {
                            directUrl = extractedVideoUrl
                            fileName = extractFileNameFromUrl(directUrl)
                            return@withContext inspectUrl(directUrl, customHeaders)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Range probe failed: ${e.message}")
        }

        // Step 2: If totalBytes still unknown, probe with standard GET
        if (totalBytes <= 0) {
            try {
                val reqBuilder = Request.Builder().url(directUrl)
                applyStandardHeaders(reqBuilder, directUrl, null)
                customHeaders.forEach { (k, v) -> reqBuilder.header(k, v) }

                httpClient.newCall(reqBuilder.build()).execute().use { response ->
                    if (response.isSuccessful) {
                        totalBytes = response.header("Content-Length")?.toLongOrNull() ?: -1L
                        val acceptRanges = response.header("Accept-Ranges")
                        if (acceptRanges != null && acceptRanges.contains("bytes", ignoreCase = true)) {
                            supportsRanges = true
                        }
                        if (mimeType == null) mimeType = response.header("Content-Type")
                        val disposition = response.header("Content-Disposition")
                        val dispName = extractFileNameFromDisposition(disposition)
                        if (!dispName.isNullOrBlank()) fileName = dispName

                        if (mimeType?.contains("text/html", ignoreCase = true) == true) {
                            val htmlBody = response.body?.string() ?: ""
                            val extracted = extractDirectMediaUrlFromHtml(htmlBody, directUrl)
                            if (!extracted.isNullOrBlank() && extracted != directUrl) {
                                directUrl = extracted
                                fileName = extractFileNameFromUrl(directUrl)
                                return@withContext inspectUrl(directUrl, customHeaders)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Standard GET probe failed: ${e.message}")
            }
        }

        val category = FileCategory.fromMimeType(mimeType).takeIf { it != FileCategory.OTHER }
            ?: FileCategory.fromFileName(fileName)
        val finalFileName = ensureExtension(sanitizeFileName(fileName), mimeType, category)

        TaskMetadata(
            directUrl = directUrl,
            fileName = finalFileName,
            totalBytes = totalBytes,
            supportsRanges = supportsRanges,
            mimeType = mimeType,
            category = category
        )
    }

    private suspend fun runDownloadPipeline(taskId: Long) = withContext(Dispatchers.IO) {
        val task = repository.getTaskById(taskId) ?: return@withContext
        try {
            repository.updateTask(task.copy(status = DownloadStatus.DOWNLOADING, errorMessage = null))
            _engineEvents.emit(EngineEvent.TaskStarted(taskId))

            var currentTask = task

            // Always inspect to get direct URL, exact size, and proper extension
            try {
                val meta = inspectUrl(currentTask.url, emptyMap())
                val resolvedName = if (currentTask.fileName.isBlank() || currentTask.fileName.startsWith("download_") || !currentTask.fileName.contains(".")) {
                    meta.fileName
                } else {
                    ensureExtension(currentTask.fileName, meta.mimeType, meta.category)
                }

                currentTask = currentTask.copy(
                    url = meta.directUrl,
                    fileName = resolvedName,
                    totalBytes = if (meta.totalBytes > 0) meta.totalBytes else currentTask.totalBytes,
                    supportsRanges = meta.supportsRanges,
                    mimeType = currentTask.mimeType ?: meta.mimeType,
                    category = if (currentTask.category == FileCategory.OTHER) meta.category else currentTask.category
                )
                repository.updateTask(currentTask)
            } catch (e: Exception) {
                Log.w(TAG, "URL pre-inspection warning: ${e.message}")
            }

            val speedTracker = speedTrackers.getOrPut(taskId) { SpeedTracker() }
            val downloadDir = FileHelper.getDownloadDir(context)
            downloadDir.mkdirs()

            val finalFile = File(downloadDir, currentTask.fileName)
            finalFile.parentFile?.mkdirs()

            // Execution: Try multi-threaded segmented download first; if anything fails, smoothly fall back to single stream
            if (currentTask.supportsRanges && currentTask.totalBytes > 256 * 1024L && currentTask.threadCount > 1) {
                try {
                    downloadSegmented(currentTask, finalFile, speedTracker)
                } catch (e: Exception) {
                    if (e is CancellationException) throw e
                    Log.w(TAG, "Multi-thread segmented download encountered issue (${e.message}), automatically falling back to single stream")
                    val tempDir = FileHelper.getTempDir(context, taskId)
                    try { tempDir.deleteRecursively() } catch (ignored: Exception) {}
                    // A failed segmented assembly must never be treated as a resumable final file.
                    if (finalFile.exists()) finalFile.delete()
                    downloadSingleStream(currentTask, finalFile, speedTracker)
                }
            } else {
                downloadSingleStream(currentTask, finalFile, speedTracker)
            }

            // Verify the final file before marking the task completed.
            val verifiedTask = repository.getTaskById(taskId)
            val expectedSize = verifiedTask?.totalBytes?.takeIf { it > 0L }
                ?: currentTask.totalBytes.takeIf { it > 0L }
            if (!finalFile.exists()) throw IOException("Downloaded file was not created.")
            if (expectedSize != null && finalFile.length() != expectedSize) {
                throw IOException("Download is incomplete. Expected $expectedSize bytes, received ${finalFile.length()} bytes.")
            }

            // Mark completed
            val updatedTask = repository.getTaskById(taskId)
            if (updatedTask != null && updatedTask.status != DownloadStatus.PAUSED && updatedTask.status != DownloadStatus.CANCELLED) {
                val fileSize = if (finalFile.exists()) finalFile.length() else updatedTask.downloadedBytes
                repository.updateTask(updatedTask.copy(
                    status = DownloadStatus.COMPLETED,
                    downloadedBytes = fileSize,
                    totalBytes = if (updatedTask.totalBytes > 0) updatedTask.totalBytes else fileSize,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    completedAt = System.currentTimeMillis()
                ))
                _engineEvents.emit(EngineEvent.TaskCompleted(taskId, finalFile))
            }
        } catch (e: CancellationException) {
            Log.d(TAG, "Task $taskId was cancelled or paused")
        } catch (e: Exception) {
            Log.e(TAG, "Task $taskId failed: ${e.message}", e)
            val curr = repository.getTaskById(taskId)
            if (curr != null) {
                repository.updateTask(curr.copy(
                    status = DownloadStatus.FAILED,
                    errorMessage = e.localizedMessage ?: "Download failed. Please verify the URL.",
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L
                ))
                _engineEvents.emit(EngineEvent.TaskFailed(taskId, e.message ?: "Download failed"))
            }
        } finally {
            activeJobs.remove(taskId)
            speedTrackers.remove(taskId)
        }
    }

    private suspend fun downloadSegmented(
        task: DownloadTask,
        finalFile: File,
        speedTracker: SpeedTracker
    ) = withContext(Dispatchers.IO) {
        val taskId = task.id
        val totalBytes = task.totalBytes
        if (totalBytes <= 0L) throw IOException("File size is unknown; segmented download cannot start.")

        val threadCount = task.threadCount.coerceIn(2, 16).coerceAtMost(totalBytes.toIntSafeChunkCount())
        val tempDir = FileHelper.getTempDir(context, taskId)
        if (!tempDir.exists() && !tempDir.mkdirs()) {
            throw IOException("Cannot create temporary download folder.")
        }
        requireAvailableSpace(tempDir, totalBytes, "temporary storage")
        finalFile.parentFile?.let {
            if (!it.exists() && !it.mkdirs()) throw IOException("Cannot create download folder.")
            requireAvailableSpace(it, totalBytes, "download storage")
        }

        var chunks = repository.getChunksForTask(taskId).sortedBy { it.chunkIndex }
        val expectedRanges = (0 until threadCount).map { index ->
            val partSize = totalBytes / threadCount
            val start = index.toLong() * partSize
            val end = if (index == threadCount - 1) totalBytes - 1L else (index + 1L) * partSize - 1L
            start to end
        }

        val rangesMatch = chunks.size == threadCount && chunks.indices.all { index ->
            chunks[index].chunkIndex == index &&
                chunks[index].startByte == expectedRanges[index].first &&
                chunks[index].endByte == expectedRanges[index].second
        }

        if (!rangesMatch) {
            repository.deleteChunksForTask(taskId)
            chunks = expectedRanges.mapIndexed { index, range ->
                DownloadChunk(
                    taskId = taskId,
                    chunkIndex = index,
                    startByte = range.first,
                    endByte = range.second
                )
            }
            repository.insertChunks(chunks)
        }

        // Reconcile database progress with actual files; the files are the source of truth.
        chunks = chunks.map { chunk ->
            val partFile = File(tempDir, "chunk_${chunk.chunkIndex}.bin")
            val required = chunk.totalChunkBytes
            if (partFile.exists() && partFile.length() > required) {
                java.io.RandomAccessFile(partFile, "rw").use { it.setLength(required) }
            }
            val actual = if (partFile.exists()) partFile.length() else 0L
            val corrected = chunk.copy(
                downloadedBytes = actual,
                isCompleted = actual == required
            )
            repository.updateChunk(corrected)
            corrected
        }

        val totalDownloadedAtomic = AtomicLong(chunks.sumOf { it.downloadedBytes })
        val lastDbSaveTime = AtomicLong(System.currentTimeMillis())

        val progressReporter = launch(Dispatchers.IO) {
            while (isActive) {
                delay(700)
                val currentDownloaded = totalDownloadedAtomic.get().coerceIn(0L, totalBytes)
                val speed = speedTracker.calculateSpeed(currentDownloaded)
                val remainingBytes = (totalBytes - currentDownloaded).coerceAtLeast(0L)
                val eta = if (speed > 0L) remainingBytes / speed else 0L
                val latestTask = repository.getTaskById(taskId)
                if (latestTask != null && latestTask.status == DownloadStatus.DOWNLOADING) {
                    repository.updateTask(latestTask.copy(
                        downloadedBytes = currentDownloaded,
                        totalBytes = totalBytes,
                        speedBytesPerSec = speed,
                        etaSeconds = eta
                    ))
                    _engineEvents.emit(EngineEvent.TaskProgress(taskId, currentDownloaded, totalBytes, speed))
                }
            }
        }

        try {
            chunks.map { chunk ->
                async(Dispatchers.IO) {
                    downloadSingleChunk(
                        task = task,
                        chunk = chunk,
                        tempDir = tempDir,
                        totalDownloadedAtomic = totalDownloadedAtomic,
                        lastDbSaveTime = lastDbSaveTime,
                        speedTracker = speedTracker
                    )
                }
            }.awaitAll()
        } finally {
            progressReporter.cancel()
        }

        // Never assemble a file from missing or truncated parts.
        chunks.forEach { chunk ->
            val partFile = File(tempDir, "chunk_${chunk.chunkIndex}.bin")
            if (!partFile.exists() || partFile.length() != chunk.totalChunkBytes) {
                throw IOException("Download part ${chunk.chunkIndex + 1} is incomplete.")
            }
        }

        assembleChunksIntoFile(chunks, tempDir, finalFile)
        if (!finalFile.exists() || finalFile.length() != totalBytes) {
            throw IOException("Final file size verification failed. Expected $totalBytes bytes, got ${finalFile.length()} bytes.")
        }

        try {
            tempDir.deleteRecursively()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clean temp dir: ${e.message}")
        }
    }

    private suspend fun downloadSingleChunk(
        task: DownloadTask,
        chunk: DownloadChunk,
        tempDir: File,
        totalDownloadedAtomic: AtomicLong,
        lastDbSaveTime: AtomicLong,
        speedTracker: SpeedTracker
    ) = withContext(Dispatchers.IO) {
        val partFile = File(tempDir, "chunk_${chunk.chunkIndex}.bin")
        val requiredBytes = chunk.totalChunkBytes
        var currentDownloaded = if (partFile.exists()) partFile.length() else 0L
        if (currentDownloaded > requiredBytes) {
            java.io.RandomAccessFile(partFile, "rw").use { it.setLength(requiredBytes) }
            currentDownloaded = requiredBytes
        }
        if (currentDownloaded == requiredBytes) return@withContext

        var retries = 0
        val maxRetries = 5

        while (currentDownloaded < requiredBytes && retries < maxRetries) {
            try {
                val rangeStart = chunk.startByte + currentDownloaded
                val rangeEnd = chunk.endByte
                val requestBuilder = Request.Builder().url(task.url)
                applyStandardHeaders(requestBuilder, task.url, task.customHeaders)
                requestBuilder.header("Range", "bytes=$rangeStart-$rangeEnd")

                httpClient.newCall(requestBuilder.build()).execute().use { response ->
                    if (response.code != 206) {
                        throw IOException("Server did not honor byte range for part ${chunk.chunkIndex + 1} (HTTP ${response.code}).")
                    }
                    val contentRange = response.header("Content-Range")
                        ?: throw IOException("Server omitted Content-Range for part ${chunk.chunkIndex + 1}.")
                    val expectedPrefix = "bytes $rangeStart-$rangeEnd/"
                    if (!contentRange.startsWith(expectedPrefix, ignoreCase = true)) {
                        throw IOException("Invalid Content-Range for part ${chunk.chunkIndex + 1}: $contentRange")
                    }
                    val body = response.body ?: throw IOException("Empty response body in part ${chunk.chunkIndex + 1}.")
                    val declaredLength = body.contentLength()
                    val remainingRequired = requiredBytes - currentDownloaded
                    if (declaredLength >= 0L && declaredLength != remainingRequired) {
                        throw IOException("Incorrect part length for part ${chunk.chunkIndex + 1}.")
                    }

                    body.byteStream().use { input ->
                        FileOutputStream(partFile, true).use { output ->
                            val buffer = ByteArray(128 * 1024)
                            var read: Int
                            var receivedThisResponse = 0L
                            var lastDbChunkBytes = 0L

                            while (input.read(buffer).also { read = it } != -1) {
                                if (receivedThisResponse + read > remainingRequired) {
                                    throw IOException("Server sent more bytes than requested for part ${chunk.chunkIndex + 1}.")
                                }
                                output.write(buffer, 0, read)
                                receivedThisResponse += read
                                currentDownloaded += read
                                lastDbChunkBytes += read
                                totalDownloadedAtomic.addAndGet(read.toLong())

                                val now = System.currentTimeMillis()
                                if (now - lastDbSaveTime.get() > 1200L && lastDbChunkBytes >= 256 * 1024L) {
                                    lastDbSaveTime.set(now)
                                    lastDbChunkBytes = 0L
                                    repository.updateChunk(chunk.copy(
                                        downloadedBytes = currentDownloaded,
                                        isCompleted = currentDownloaded == requiredBytes
                                    ))
                                }
                            }
                            output.flush()
                            if (receivedThisResponse != remainingRequired) {
                                throw IOException("Connection ended early while downloading part ${chunk.chunkIndex + 1}.")
                            }
                        }
                    }
                }

                repository.updateChunk(chunk.copy(
                    downloadedBytes = currentDownloaded,
                    isCompleted = currentDownloaded == requiredBytes
                ))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                retries++
                Log.w(TAG, "Chunk ${chunk.chunkIndex} error: ${e.message}, retry $retries/$maxRetries")
                if (retries >= maxRetries) throw e
                delay(1000L * retries)
                currentDownloaded = if (partFile.exists()) partFile.length().coerceAtMost(requiredBytes) else 0L
                totalDownloadedAtomic.set(
                    totalDownloadedAtomic.get().coerceAtLeast(currentDownloaded)
                )
            }
        }

        if (currentDownloaded != requiredBytes) {
            throw IOException("Part ${chunk.chunkIndex + 1} did not finish.")
        }
    }

    private suspend fun assembleChunksIntoFile(
        chunks: List<DownloadChunk>,
        tempDir: File,
        finalFile: File
    ) = withContext(Dispatchers.IO) {
        val sorted = chunks.sortedBy { it.chunkIndex }
        FileOutputStream(finalFile, false).use { out ->
            val buffer = ByteArray(256 * 1024)
            for (chunk in sorted) {
                val partFile = File(tempDir, "chunk_${chunk.chunkIndex}.bin")
                if (!partFile.exists() || partFile.length() != chunk.totalChunkBytes) {
                    throw IOException("Cannot assemble file: part ${chunk.chunkIndex + 1} is missing or incomplete.")
                }
                FileInputStream(partFile).use { input ->
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        out.write(buffer, 0, read)
                    }
                }
            }
            out.fd.sync()
        }
    }

    private fun requireAvailableSpace(directory: File, requiredBytes: Long, label: String) {
        val usable = directory.usableSpace
        val safetyMargin = maxOf(64L * 1024L * 1024L, requiredBytes / 100L)
        if (usable > 0L && usable < requiredBytes + safetyMargin) {
            throw IOException("Not enough $label. Required about ${formatBytes(requiredBytes + safetyMargin)}, available ${formatBytes(usable)}.")
        }
    }

    private fun formatBytes(bytes: Long): String {
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unit = 0
        while (value >= 1024.0 && unit < units.lastIndex) {
            value /= 1024.0
            unit++
        }
        return String.format(java.util.Locale.US, "%.2f %s", value, units[unit])
    }

    private fun Long.toIntSafeChunkCount(): Int {
        return if (this > Int.MAX_VALUE.toLong()) Int.MAX_VALUE else this.toInt()
    }

    private suspend fun downloadSingleStream(
        task: DownloadTask,
        finalFile: File,
        speedTracker: SpeedTracker
    ) = withContext(Dispatchers.IO) {
        val taskId = task.id
        finalFile.parentFile?.mkdirs()

        var currentDownloaded = if (finalFile.exists()) finalFile.length() else 0L
        val canResume = task.supportsRanges && currentDownloaded > 0L

        val reqBuilder = Request.Builder().url(task.url)
        applyStandardHeaders(reqBuilder, task.url, task.customHeaders)

        if (canResume) {
            reqBuilder.header("Range", "bytes=$currentDownloaded-")
        }

        val response = httpClient.newCall(reqBuilder.build()).execute()
        if (!response.isSuccessful) {
            val code = response.code
            val msg = response.message
            response.close()
            throw IOException("Server returned HTTP $code ($msg)")
        }

        val isPartial = response.code == 206
        if (canResume && isPartial) {
            val contentRange = response.header("Content-Range")
            if (contentRange == null || !contentRange.startsWith("bytes $currentDownloaded-", ignoreCase = true)) {
                response.close()
                throw IOException("Server returned an invalid Content-Range while resuming the download.")
            }
        }
        val append = canResume && isPartial
        if (!append) {
            currentDownloaded = 0L
            if (finalFile.exists()) finalFile.delete()
        }

        // Determine total bytes
        var totalBytes = task.totalBytes
        val contentLength = response.header("Content-Length")?.toLongOrNull() ?: -1L
        if (contentLength > 0) {
            totalBytes = if (isPartial) currentDownloaded + contentLength else contentLength
            val curr = repository.getTaskById(taskId)
            if (curr != null && (curr.totalBytes <= 0 || curr.totalBytes != totalBytes)) {
                repository.updateTask(curr.copy(totalBytes = totalBytes))
            }
        }

        if (totalBytes > 0L) {
            finalFile.parentFile?.let {
                requireAvailableSpace(it, (totalBytes - currentDownloaded).coerceAtLeast(0L), "download storage")
            }
        }

        val body = response.body ?: throw IOException("Empty response body from server")
        val inputStream = body.byteStream()
        val outputStream = FileOutputStream(finalFile, append)

        val buffer = ByteArray(64 * 1024)
        var bytesRead: Int
        var lastDbUpdate = System.currentTimeMillis()

        try {
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
                currentDownloaded += bytesRead

                val now = System.currentTimeMillis()
                if (now - lastDbUpdate >= 500) {
                    lastDbUpdate = now
                    val speed = speedTracker.calculateSpeed(currentDownloaded)
                    val remaining = if (totalBytes > 0) (totalBytes - currentDownloaded).coerceAtLeast(0L) else 0L
                    val eta = if (speed > 0) remaining / speed else 0L

                    val curr = repository.getTaskById(taskId)
                    if (curr != null && curr.status == DownloadStatus.DOWNLOADING) {
                        repository.updateTask(curr.copy(
                            downloadedBytes = currentDownloaded,
                            totalBytes = if (totalBytes > 0) totalBytes else curr.totalBytes,
                            speedBytesPerSec = speed,
                            etaSeconds = eta
                        ))
                        _engineEvents.emit(EngineEvent.TaskProgress(taskId, currentDownloaded, totalBytes, speed))
                    }
                }
            }
            outputStream.flush()
        } finally {
            try { outputStream.close() } catch (ignored: Exception) {}
            try { inputStream.close() } catch (ignored: Exception) {}
            try { body.close() } catch (ignored: Exception) {}
        }

        if (totalBytes > 0L && currentDownloaded != totalBytes) {
            throw IOException("Download ended before completion. Expected $totalBytes bytes, received $currentDownloaded bytes.")
        }
    }

    private fun extractDirectMediaUrlFromHtml(html: String, baseUrl: String): String? {
        try {
            val ogVideoMatch = """<meta\s+property=["']og:video(?:[:\w]+)?["']\s+content=["']([^"']+)["']""".toRegex(RegexOption.IGNORE_CASE).find(html)
                ?: """<meta\s+content=["']([^"']+)["']\s+property=["']og:video(?:[:\w]+)?["']""".toRegex(RegexOption.IGNORE_CASE).find(html)
            if (ogVideoMatch != null) {
                val raw = ogVideoMatch.groupValues[1]
                if (raw.isNotBlank() && !raw.endsWith(".html", ignoreCase = true)) {
                    return resolveUrl(baseUrl, raw)
                }
            }

            val videoSrcMatch = """<video[^>]+src=["']([^"']+)["']""".toRegex(RegexOption.IGNORE_CASE).find(html)
            if (videoSrcMatch != null) {
                return resolveUrl(baseUrl, videoSrcMatch.groupValues[1])
            }

            val sourceSrcMatch = """<source[^>]+src=["']([^"']+)["']""".toRegex(RegexOption.IGNORE_CASE).find(html)
            if (sourceSrcMatch != null) {
                return resolveUrl(baseUrl, sourceSrcMatch.groupValues[1])
            }

            val directLinkMatch = """["'](https?://[^"'\s<>]+\.(?:mp4|mkv|webm|mov|avi|flv)(?:\?[^"'\s<>]*)?)["']""".toRegex(RegexOption.IGNORE_CASE).find(html)
            if (directLinkMatch != null) {
                return directLinkMatch.groupValues[1]
            }
        } catch (ignored: Exception) {}
        return null
    }

    private fun resolveUrl(base: String, relative: String): String {
        return try {
            if (relative.startsWith("http://") || relative.startsWith("https://")) {
                relative
            } else if (relative.startsWith("//")) {
                val scheme = Uri.parse(base).scheme ?: "https"
                "$scheme:$relative"
            } else {
                val baseUri = Uri.parse(base)
                val host = "${baseUri.scheme}://${baseUri.host}"
                if (relative.startsWith("/")) "$host$relative" else "$host/$relative"
            }
        } catch (e: Exception) {
            relative
        }
    }

    private fun ensureExtension(fileName: String, mime: String?, category: FileCategory): String {
        val clean = fileName.trim()
        val hasExt = clean.contains(".") && !clean.endsWith(".")
        if (hasExt) return clean

        val ext = when {
            mime?.contains("video/mp4", ignoreCase = true) == true -> "mp4"
            mime?.contains("video/webm", ignoreCase = true) == true -> "webm"
            mime?.contains("video/x-matroska", ignoreCase = true) == true -> "mkv"
            mime?.contains("video", ignoreCase = true) == true -> "mp4"
            mime?.contains("audio/mpeg", ignoreCase = true) == true || mime?.contains("mp3", ignoreCase = true) == true -> "mp3"
            mime?.contains("audio", ignoreCase = true) == true -> "mp3"
            mime?.contains("image/jpeg", ignoreCase = true) == true -> "jpg"
            mime?.contains("image/png", ignoreCase = true) == true -> "png"
            mime?.contains("pdf", ignoreCase = true) == true -> "pdf"
            mime?.contains("zip", ignoreCase = true) == true -> "zip"
            category == FileCategory.VIDEO -> "mp4"
            category == FileCategory.AUDIO -> "mp3"
            category == FileCategory.DOCUMENT -> "pdf"
            category == FileCategory.IMAGE -> "jpg"
            category == FileCategory.ARCHIVE -> "zip"
            else -> "mp4" // Default to mp4 if video or unknown
        }
        return "$clean.$ext"
    }

    private fun extractFileNameFromUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            var candidate = uri.lastPathSegment
            if (candidate.isNullOrBlank() || candidate == "/" || candidate.contains("=")) {
                candidate = "video_${System.currentTimeMillis()}"
            }
            candidate = candidate.substringBefore("?").substringBefore("#")
            URLDecoder.decode(candidate, "UTF-8")
        } catch (e: Exception) {
            "video_${System.currentTimeMillis()}"
        }
    }

    private fun extractFileNameFromDisposition(disposition: String?): String? {
        if (disposition == null) return null
        val filenameRegex = """filename\*?=(?:UTF-8'')?["']?([^"';]+)["']?""".toRegex(RegexOption.IGNORE_CASE)
        val match = filenameRegex.find(disposition)
        return match?.groupValues?.get(1)?.let {
            try {
                URLDecoder.decode(it, "UTF-8")
            } catch (e: Exception) {
                it
            }
        }
    }

    private fun sanitizeFileName(name: String): String {
        val sanitized = name.replace("""[\\/:*?"<>|]""".toRegex(), "_").trim()
        return if (sanitized.isBlank()) "video_${System.currentTimeMillis()}" else sanitized
    }

    companion object {
        private const val TAG = "DownloadEngine"
        const val BROWSER_USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0 Chrome/130.0.0.0 Mobile Safari/537.36"

        @Volatile
        private var INSTANCE: DownloadEngine? = null

        fun getInstance(context: Context, repository: DownloadRepository): DownloadEngine {
            return INSTANCE ?: synchronized(this) {
                val instance = DownloadEngine(context.applicationContext, repository)
                INSTANCE = instance
                instance
            }
        }
    }
}
