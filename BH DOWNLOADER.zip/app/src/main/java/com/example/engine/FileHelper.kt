package com.example.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

object FileHelper {

    suspend fun calculateChecksum(file: File, algorithm: String = "MD5"): String = withContext(Dispatchers.IO) {
        if (!file.exists() || !file.canRead()) return@withContext "File not found"
        try {
            val digest = MessageDigest.getInstance(algorithm)
            val buffer = ByteArray(1024 * 64)
            FileInputStream(file).use { fis ->
                var read: Int
                while (fis.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    fun openFile(context: Context, filePath: String, mimeType: String? = null): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false

        try {
            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)

            val resolvedMime = mimeType ?: getMimeType(file) ?: "*/*"

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, resolvedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, file.name).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun shareFile(context: Context, filePath: String, mimeType: String? = null): Boolean {
        val file = File(filePath)
        if (!file.exists()) return false

        try {
            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)
            val resolvedMime = mimeType ?: getMimeType(file) ?: "*/*"

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = resolvedMime
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, file.name)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share ${file.name}").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun getMimeType(file: File): String? {
        val extension = file.extension.lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
    }

    fun getDownloadDir(context: Context): File {
        val external = context.getExternalFilesDir(null)
        val dir = if (external != null) {
            File(external, "Downloads")
        } else {
            File(context.filesDir, "Downloads")
        }
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getTempDir(context: Context, taskId: Long): File {
        val dir = File(context.filesDir, "temp_chunks/task_$taskId")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }
}
