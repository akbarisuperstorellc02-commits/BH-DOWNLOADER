package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.localization.AppLanguage
import com.example.localization.AppStrings

enum class FileCategory(val key: String) {
    ALL("all"),
    VIDEO("video"),
    AUDIO("audio"),
    IMAGE("image"),
    DOCUMENT("document"),
    ARCHIVE("archive"),
    OTHER("other");

    fun localizedTitle(lang: AppLanguage): String = when (this) {
        ALL -> AppStrings.tabAll(lang)
        VIDEO -> AppStrings.catVideos(lang)
        AUDIO -> AppStrings.catMusic(lang)
        IMAGE -> AppStrings.catImages(lang)
        DOCUMENT -> AppStrings.catDocuments(lang)
        ARCHIVE -> AppStrings.catArchives(lang)
        OTHER -> AppStrings.catOther(lang)
    }

    val icon: ImageVector
        get() = when (this) {
            ALL -> Icons.Default.Folder
            VIDEO -> Icons.Default.Videocam
            AUDIO -> Icons.Default.Audiotrack
            IMAGE -> Icons.Default.Image
            DOCUMENT -> Icons.Default.Description
            ARCHIVE -> Icons.Default.Archive
            OTHER -> Icons.Default.Folder
        }

    companion object {
        fun fromFileName(name: String): FileCategory {
            val ext = name.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "3gp", "m4v" -> VIDEO
                "mp3", "wav", "aac", "flac", "ogg", "m4a", "wma", "opus" -> AUDIO
                "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg" -> IMAGE
                "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv" -> DOCUMENT
                "zip", "rar", "7z", "tar", "gz", "bz2", "apk", "xapk", "apks", "iso", "bin", "dmg" -> ARCHIVE
                else -> OTHER
            }
        }

        fun fromMimeType(mime: String?): FileCategory {
            if (mime == null) return OTHER
            val lower = mime.lowercase()
            return when {
                lower.startsWith("video/") -> VIDEO
                lower.startsWith("audio/") -> AUDIO
                lower.startsWith("image/") -> IMAGE
                lower.contains("pdf") || lower.contains("text/") || lower.contains("document") || lower.contains("msword") || lower.contains("sheet") -> DOCUMENT
                lower.contains("zip") || lower.contains("archive") || lower.contains("android.package-archive") || lower.contains("compressed") -> ARCHIVE
                else -> OTHER
            }
        }
    }
}
