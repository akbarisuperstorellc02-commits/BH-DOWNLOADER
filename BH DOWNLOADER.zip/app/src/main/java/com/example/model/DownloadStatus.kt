package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.localization.AppLanguage
import com.example.localization.AppStrings

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED;

    fun localizedTitle(lang: AppLanguage): String = when (this) {
        QUEUED -> AppStrings.statusQueued(lang)
        DOWNLOADING -> AppStrings.statusDownloading(lang)
        PAUSED -> AppStrings.statusPaused(lang)
        COMPLETED -> AppStrings.statusCompleted(lang)
        FAILED -> AppStrings.statusFailed(lang)
        CANCELLED -> AppStrings.cancel(lang)
    }

    val isActive: Boolean
        get() = this == DOWNLOADING || this == QUEUED

    val isTerminal: Boolean
        get() = this == COMPLETED || this == CANCELLED
}
