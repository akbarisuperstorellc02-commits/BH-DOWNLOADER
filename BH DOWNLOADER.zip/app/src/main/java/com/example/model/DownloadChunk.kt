package com.example.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "download_chunks",
    indices = [Index(value = ["taskId"])]
)
data class DownloadChunk(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskId: Long,
    val chunkIndex: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long = 0L,
    val isCompleted: Boolean = false
) {
    val totalChunkBytes: Long
        get() = (endByte - startByte + 1L).coerceAtLeast(0L)

    val progress: Float
        get() = if (totalChunkBytes > 0) {
            (downloadedBytes.toFloat() / totalChunkBytes.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
}
