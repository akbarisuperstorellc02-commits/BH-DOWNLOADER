package com.example

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import com.example.data.AppDatabase
import com.example.data.DownloadRepository
import com.example.engine.DownloadEngine
import com.example.localization.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class BHDownloaderApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: DownloadRepository
        private set

    lateinit var engine: DownloadEngine
        private set

    private lateinit var prefs: SharedPreferences

    private val _currentLanguage = MutableStateFlow(AppLanguage.DARI)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _themeMode = MutableStateFlow("system") // "system", "dark", "light"
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _defaultThreads = MutableStateFlow(8)
    val defaultThreads: StateFlow<Int> = _defaultThreads.asStateFlow()

    private val _clipboardDetectionEnabled = MutableStateFlow(true)
    val clipboardDetectionEnabled: StateFlow<Boolean> = _clipboardDetectionEnabled.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        repository = DownloadRepository(database.downloadDao())
        engine = DownloadEngine.getInstance(this, repository)

        prefs = getSharedPreferences("bh_downloader_prefs", Context.MODE_PRIVATE)

        val savedLangCode = prefs.getString("app_language", AppLanguage.DARI.code) ?: AppLanguage.DARI.code
        val matchedLang = AppLanguage.values().firstOrNull { it.code == savedLangCode } ?: AppLanguage.DARI
        _currentLanguage.value = matchedLang

        _themeMode.value = prefs.getString("theme_mode", "dark") ?: "dark"
        _defaultThreads.value = prefs.getInt("default_threads", 8)
        _clipboardDetectionEnabled.value = prefs.getBoolean("clipboard_detect", true)
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        prefs.edit().putString("app_language", language.code).apply()
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode).apply()
    }

    fun setDefaultThreads(threads: Int) {
        _defaultThreads.value = threads.coerceIn(1, 16)
        prefs.edit().putInt("default_threads", threads).apply()
    }

    fun setClipboardDetection(enabled: Boolean) {
        _clipboardDetectionEnabled.value = enabled
        prefs.edit().putBoolean("clipboard_detect", enabled).apply()
    }

    companion object {
        lateinit var instance: BHDownloaderApp
            private set
    }
}
