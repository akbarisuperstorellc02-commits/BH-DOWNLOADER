package com.example.data

import com.example.model.DownloadChunk
import com.example.model.DownloadStatus
import com.example.model.DownloadTask
import kotlinx.coroutines.flow.Flow

class DownloadRepository(private val dao: DownloadDao) {
    val allTasks: Flow<List<DownloadTask>> = dao.getAllTasks()

    suspend fun getTaskById(id: Long): DownloadTask? = dao.getTaskById(id)

    fun getTaskFlow(id: Long): Flow<DownloadTask?> = dao.getTaskFlow(id)

    suspend fun insertTask(task: DownloadTask): Long = dao.insertTask(task)

    suspend fun updateTask(task: DownloadTask) = dao.updateTask(task)

    suspend fun deleteTask(task: DownloadTask) = dao.deleteTask(task)

    suspend fun deleteTaskById(id: Long) {
        dao.deleteChunksForTask(id)
        dao.deleteTaskById(id)
    }

    suspend fun deleteCompletedTasks() = dao.deleteCompletedTasks()

    suspend fun getChunksForTask(taskId: Long): List<DownloadChunk> = dao.getChunksForTask(taskId)

    fun getChunksFlowForTask(taskId: Long): Flow<List<DownloadChunk>> = dao.getChunksFlowForTask(taskId)

    suspend fun insertChunks(chunks: List<DownloadChunk>) = dao.insertChunks(chunks)

    suspend fun updateChunk(chunk: DownloadChunk) = dao.updateChunk(chunk)

    suspend fun deleteChunksForTask(taskId: Long) = dao.deleteChunksForTask(taskId)
}
