package com.example.data

import androidx.room.TypeConverter
import com.example.model.DownloadStatus
import com.example.model.FileCategory

class Converters {
    @TypeConverter
    fun fromFileCategory(category: FileCategory): String = category.name

    @TypeConverter
    fun toFileCategory(value: String): FileCategory = try {
        FileCategory.valueOf(value)
    } catch (e: Exception) {
        FileCategory.OTHER
    }

    @TypeConverter
    fun fromDownloadStatus(status: DownloadStatus): String = status.name

    @TypeConverter
    fun toDownloadStatus(value: String): DownloadStatus = try {
        DownloadStatus.valueOf(value)
    } catch (e: Exception) {
        DownloadStatus.QUEUED
    }
}
