package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.BHDownloaderApp
import com.example.MainActivity
import com.example.R
import com.example.engine.DownloadEngine
import com.example.localization.formatBytes
import com.example.localization.formatSpeed
import com.example.model.DownloadStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DownloadForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var notificationManager: NotificationManager

    companion object {
        const val CHANNEL_ID = "bh_downloader_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_DOWNLOAD = "com.example.bhdownloader.ACTION_START"
        const val ACTION_PAUSE_DOWNLOAD = "com.example.bhdownloader.ACTION_PAUSE"
        const val ACTION_RESUME_DOWNLOAD = "com.example.bhdownloader.ACTION_RESUME"
        const val ACTION_CANCEL_DOWNLOAD = "com.example.bhdownloader.ACTION_CANCEL"
        const val EXTRA_TASK_ID = "extra_task_id"

        fun startService(context: Context, taskId: Long) {
            try {
                val intent = Intent(context, DownloadForegroundService::class.java).apply {
                    action = ACTION_START_DOWNLOAD
                    putExtra(EXTRA_TASK_ID, taskId)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                // If foreground service cannot start from background, download engine still runs in app process
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    createInitialNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, createInitialNotification())
            }
        } catch (e: Exception) {
            // Fallback if foreground service is restricted
        }

        observeDownloads()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BH Downloader Active Tasks",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress and speed for active downloads"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createInitialNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.bh_downloader_icon_1793785546417)
            .setContentTitle("BH Downloader")
            .setContentText("Download service active")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun observeDownloads() {
        val app = application as BHDownloaderApp
        val repository = app.repository

        serviceScope.launch {
            repository.allTasks.collectLatest { tasks ->
                val activeTasks = tasks.filter { it.status == DownloadStatus.DOWNLOADING }
                if (activeTasks.isEmpty()) {
                    val anyQueued = tasks.any { it.status == DownloadStatus.QUEUED }
                    if (!anyQueued) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                } else {
                    val primary = activeTasks.first()
                    val totalSpeed = activeTasks.sumOf { it.speedBytesPerSec }
                    val content = "${formatSpeed(totalSpeed)} • ${formatBytes(primary.downloadedBytes)} / ${if (primary.totalBytes > 0) formatBytes(primary.totalBytes) else "--"}"

                    val openAppIntent = Intent(this@DownloadForegroundService, MainActivity::class.java)
                    val pendingIntent = PendingIntent.getActivity(
                        this@DownloadForegroundService, 0, openAppIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )

                    val notification = NotificationCompat.Builder(this@DownloadForegroundService, CHANNEL_ID)
                        .setSmallIcon(R.drawable.bh_downloader_icon_1793785546417)
                        .setContentTitle("${primary.fileName} (${activeTasks.size} active)")
                        .setContentText(content)
                        .setContentIntent(pendingIntent)
                        .setProgress(100, primary.progressPercent, primary.totalBytes <= 0)
                        .setOngoing(true)
                        .setSilent(true)
                        .setPriority(NotificationCompat.PRIORITY_LOW)
                        .build()

                    notificationManager.notify(NOTIFICATION_ID, notification)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as? BHDownloaderApp
        val engine = app?.engine
        val taskId = intent?.getLongExtra(EXTRA_TASK_ID, -1L) ?: -1L

        when (intent?.action) {
            ACTION_START_DOWNLOAD, ACTION_RESUME_DOWNLOAD -> {
                if (taskId > 0 && engine != null) {
                    engine.startOrResume(taskId)
                }
            }
            ACTION_PAUSE_DOWNLOAD -> {
                if (taskId > 0 && engine != null) {
                    engine.pauseDownload(taskId)
                }
            }
            ACTION_CANCEL_DOWNLOAD -> {
                if (taskId > 0 && engine != null) {
                    engine.cancelDownload(taskId)
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
