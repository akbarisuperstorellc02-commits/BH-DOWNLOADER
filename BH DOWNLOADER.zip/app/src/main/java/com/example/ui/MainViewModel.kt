package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BHDownloaderApp
import com.example.engine.DownloadEngine
import com.example.engine.FileHelper
import com.example.localization.AppLanguage
import com.example.model.DownloadChunk
import com.example.model.DownloadStatus
import com.example.model.DownloadTask
import com.example.model.FileCategory
import com.example.service.DownloadForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as BHDownloaderApp
    private val repository = app.repository
    private val engine = app.engine

    val language: StateFlow<AppLanguage> = app.currentLanguage
    val themeMode: StateFlow<String> = app.themeMode
    val defaultThreads: StateFlow<Int> = app.defaultThreads
    val clipboardDetectionEnabled: StateFlow<Boolean> = app.clipboardDetectionEnabled

    val allTasks: StateFlow<List<DownloadTask>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedTab = MutableStateFlow(0) // 0: All, 1: Downloading, 2: Completed, 3: Categories, 4: Browser/Tests
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _selectedCategory = MutableStateFlow(FileCategory.ALL)
    val selectedCategory: StateFlow<FileCategory> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _detectedClipboardUrl = MutableStateFlow<String?>(null)
    val detectedClipboardUrl: StateFlow<String?> = _detectedClipboardUrl.asStateFlow()

    private val _isAddDialogOpen = MutableStateFlow(false)
    val isAddDialogOpen: StateFlow<Boolean> = _isAddDialogOpen.asStateFlow()

    private val _prefilledUrl = MutableStateFlow("")
    val prefilledUrl: StateFlow<String> = _prefilledUrl.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _detailTask = MutableStateFlow<DownloadTask?>(null)
    val detailTask: StateFlow<DownloadTask?> = _detailTask.asStateFlow()

    // Filtered tasks according to active tab, category, and search query
    val filteredTasks: StateFlow<List<DownloadTask>> = combine(
        allTasks,
        selectedTab,
        selectedCategory,
        searchQuery
    ) { tasks, tab, category, query ->
        var list = tasks

        // Tab filter
        list = when (tab) {
            1 -> list.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
            2 -> list.filter { it.status == DownloadStatus.COMPLETED }
            3 -> if (category == FileCategory.ALL) list else list.filter { it.category == category }
            else -> list
        }

        // Search query filter
        if (query.isNotBlank()) {
            list = list.filter {
                it.fileName.contains(query, ignoreCase = true) || it.url.contains(query, ignoreCase = true)
            }
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Overall current downloading speed
    val totalDownloadSpeed: StateFlow<Long> = allTasks.combine(selectedTab) { tasks, _ ->
        tasks.filter { it.status == DownloadStatus.DOWNLOADING }.sumOf { it.speedBytesPerSec }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    private val _speedHistory = MutableStateFlow<List<Long>>(List(30) { 0L })
    val speedHistory: StateFlow<List<Long>> = _speedHistory.asStateFlow()

    private val _peakSpeed = MutableStateFlow(0L)
    val peakSpeed: StateFlow<Long> = _peakSpeed.asStateFlow()

    val averageSpeed: StateFlow<Long> = _speedHistory.map { list ->
        val nonZero = list.filter { it > 0 }
        if (nonZero.isNotEmpty()) nonZero.average().toLong() else 0L
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val activeStreamsCount: StateFlow<Int> = allTasks.map { tasks ->
        tasks.filter { it.status == DownloadStatus.DOWNLOADING }.sumOf { it.threadCount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    init {
        viewModelScope.launch {
            while (isActive) {
                delay(600)
                val current = totalDownloadSpeed.value
                val oldList = _speedHistory.value
                val newList = (oldList.drop(1) + current)
                _speedHistory.value = newList
                if (current > _peakSpeed.value) {
                    _peakSpeed.value = current
                }
            }
        }
    }

    fun startDemoStream() {
        addDownload(
            url = "https://speed.hetzner.de/10MB.bin",
            fileName = "turbo_benchmark_${System.currentTimeMillis() % 10000}.bin",
            threadCount = 8,
            category = FileCategory.OTHER,
            startImmediately = true
        )
    }

    fun selectTab(tab: Int) {
        _selectedTab.value = tab
    }

    fun selectCategory(category: FileCategory) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openAddDialog(initialUrl: String = "") {
        _prefilledUrl.value = initialUrl
        _isAddDialogOpen.value = true
    }

    fun closeAddDialog() {
        _isAddDialogOpen.value = false
        _prefilledUrl.value = ""
    }

    fun openSettings() {
        _isSettingsOpen.value = true
    }

    fun closeSettings() {
        _isSettingsOpen.value = false
    }

    fun showDetails(task: DownloadTask) {
        _detailTask.value = task
    }

    fun closeDetails() {
        _detailTask.value = null
    }

    fun setLanguage(lang: AppLanguage) {
        app.setLanguage(lang)
    }

    fun setThemeMode(mode: String) {
        app.setThemeMode(mode)
    }

    fun setDefaultThreads(threads: Int) {
        app.setDefaultThreads(threads)
    }

    fun setClipboardDetection(enabled: Boolean) {
        app.setClipboardDetection(enabled)
    }

    fun onClipboardDetected(url: String) {
        if (!clipboardDetectionEnabled.value) return
        if (url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)) {
            // Check if not already added
            val alreadyPresent = allTasks.value.any { it.url.equals(url, ignoreCase = true) && !it.status.isTerminal }
            if (!alreadyPresent && _detectedClipboardUrl.value != url) {
                _detectedClipboardUrl.value = url
            }
        }
    }

    fun dismissClipboardPrompt() {
        _detectedClipboardUrl.value = null
    }

    fun acceptClipboardPrompt() {
        val url = _detectedClipboardUrl.value ?: return
        dismissClipboardPrompt()
        openAddDialog(url)
    }

    suspend fun inspectUrl(url: String): DownloadEngine.TaskMetadata {
        return engine.inspectUrl(url)
    }

    fun addDownload(
        url: String,
        fileName: String,
        threadCount: Int,
        category: FileCategory,
        customHeaders: String? = null,
        startImmediately: Boolean = true
    ) {
        viewModelScope.launch {
            val downloadDir = FileHelper.getDownloadDir(getApplication())
            val resolvedFileName = if (fileName.isBlank()) {
                "download_${System.currentTimeMillis()}"
            } else {
                fileName.trim()
            }
            val finalPath = File(downloadDir, resolvedFileName).absolutePath

            val task = DownloadTask(
                url = url.trim(),
                fileName = resolvedFileName,
                filePath = finalPath,
                category = category,
                threadCount = threadCount.coerceIn(1, 16),
                status = if (startImmediately) DownloadStatus.QUEUED else DownloadStatus.PAUSED,
                customHeaders = customHeaders
            )

            val insertedId = repository.insertTask(task)
            if (startImmediately) {
                DownloadForegroundService.startService(getApplication(), insertedId)
                engine.startOrResume(insertedId)
            }
        }
    }

    fun pauseDownload(taskId: Long) {
        engine.pauseDownload(taskId)
    }

    fun resumeDownload(taskId: Long) {
        DownloadForegroundService.startService(getApplication(), taskId)
        engine.startOrResume(taskId)
    }

    fun cancelOrDeleteDownload(taskId: Long, deleteFileFromDisk: Boolean) {
        engine.cancelDownload(taskId, deleteFileFromDisk)
    }

    fun pauseAll() {
        engine.pauseAll()
    }

    fun resumeAll() {
        viewModelScope.launch {
            val paused = allTasks.value.filter { it.status == DownloadStatus.PAUSED || it.status == DownloadStatus.QUEUED }
            for (task in paused) {
                DownloadForegroundService.startService(getApplication(), task.id)
                engine.startOrResume(task.id)
            }
        }
    }

    fun clearCompleted() {
        viewModelScope.launch {
            repository.deleteCompletedTasks()
        }
    }

    fun openFile(context: Context, task: DownloadTask): Boolean {
        return FileHelper.openFile(context, task.filePath, task.mimeType)
    }

    fun shareFile(context: Context, task: DownloadTask): Boolean {
        return FileHelper.shareFile(context, task.filePath, task.mimeType)
    }

    fun getChunksFlow(taskId: Long): Flow<List<DownloadChunk>> {
        return repository.getChunksFlowForTask(taskId)
    }

    suspend fun calculateChecksum(task: DownloadTask, algorithm: String = "MD5"): String {
        return withContext(Dispatchers.IO) {
            val file = File(task.filePath)
            FileHelper.calculateChecksum(file, algorithm)
        }
    }
}
