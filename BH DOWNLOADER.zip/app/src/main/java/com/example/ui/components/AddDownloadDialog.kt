package com.example.ui.components

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.localization.formatBytes
import com.example.model.FileCategory
import com.example.ui.MainViewModel
import com.example.ui.theme.TurboAmber
import com.example.ui.theme.TurboCyan
import com.example.ui.theme.TurboEmerald
import kotlinx.coroutines.launch

@Composable
fun AddDownloadDialog(
    initialUrl: String,
    viewModel: MainViewModel,
    lang: AppLanguage,
    defaultThreads: Int,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf(initialUrl) }
    var fileName by remember { mutableStateOf("") }
    var threadCount by remember { mutableFloatStateOf(defaultThreads.toFloat()) }
    var selectedCategory by remember { mutableStateOf(FileCategory.OTHER) }

    var isInspecting by remember { mutableStateOf(false) }
    var inspectionResult by remember { mutableStateOf<String?>(null) }
    var detectedSize by remember { mutableStateOf(-1L) }
    var supportsRange by remember { mutableStateOf(true) }

    var showAdvanced by remember { mutableStateOf(false) }
    var customUserAgent by remember { mutableStateOf("") }

    // Auto inspect initial URL if provided
    LaunchedEffect(initialUrl) {
        if (initialUrl.isNotBlank() && (initialUrl.startsWith("http://") || initialUrl.startsWith("https://"))) {
            isInspecting = true
            try {
                val meta = viewModel.inspectUrl(initialUrl)
                if (meta.directUrl.isNotBlank() && meta.directUrl != url) {
                    url = meta.directUrl
                }
                fileName = meta.fileName
                detectedSize = meta.totalBytes
                supportsRange = meta.supportsRanges
                selectedCategory = meta.category
                val sizeText = if (meta.totalBytes > 0) formatBytes(meta.totalBytes) else "Stream ready"
                val rangeText = if (meta.supportsRanges) "✓ Turbo Multi-thread Range OK" else "Single stream ready"
                inspectionResult = "$sizeText • $rangeText"
            } catch (e: Exception) {
                inspectionResult = "Ready to download"
            } finally {
                isInspecting = false
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = TurboCyan,
                    modifier = Modifier.size(26.dp)
                )
                Text(
                    text = AppStrings.addDownload(lang),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // URL Input with Paste & Inspect buttons
                OutlinedTextField(
                    value = url,
                    onValueChange = {
                        url = it
                        inspectionResult = null
                    },
                    label = { Text(AppStrings.enterUrl(lang)) },
                    placeholder = { Text("https://example.com/file.zip") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = {
                        Row {
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = clipboard.primaryClip
                                if (clip != null && clip.itemCount > 0) {
                                    val text = clip.getItemAt(0).text?.toString() ?: ""
                                    if (text.isNotBlank()) {
                                        url = text
                                    }
                                }
                            }) {
                                Icon(Icons.Default.ContentPaste, contentDescription = "Paste", tint = TurboCyan)
                            }

                            IconButton(
                                onClick = {
                                    if (url.isNotBlank()) {
                                        scope.launch {
                                            isInspecting = true
                                            try {
                                                val meta = viewModel.inspectUrl(url)
                                                if (meta.directUrl.isNotBlank() && meta.directUrl != url) {
                                                    url = meta.directUrl
                                                }
                                                fileName = meta.fileName
                                                detectedSize = meta.totalBytes
                                                supportsRange = meta.supportsRanges
                                                selectedCategory = meta.category
                                                val sizeText = if (meta.totalBytes > 0) formatBytes(meta.totalBytes) else "Stream ready"
                                                val rangeText = if (meta.supportsRanges) "✓ Multi-thread Range OK" else "Single stream ready"
                                                inspectionResult = "$sizeText • $rangeText"
                                            } catch (e: Exception) {
                                                inspectionResult = "Ready to download"
                                            } finally {
                                                isInspecting = false
                                            }
                                        }
                                    }
                                }
                            ) {
                                if (isInspecting) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Default.Search, contentDescription = "Inspect", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                )

                // Inspection pill info
                if (inspectionResult != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (supportsRange) TurboEmerald.copy(alpha = 0.15f) else TurboAmber.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (supportsRange) Icons.Default.Check else Icons.Default.Link,
                                contentDescription = null,
                                tint = if (supportsRange) TurboEmerald else TurboAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = inspectionResult ?: "",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 11.sp
                                ),
                                color = if (supportsRange) TurboEmerald else TurboAmber
                            )
                        }
                    }
                }

                // File Name Input
                OutlinedTextField(
                    value = fileName,
                    onValueChange = {
                        fileName = it
                        selectedCategory = FileCategory.fromFileName(it)
                    },
                    label = { Text(AppStrings.fileName(lang)) },
                    placeholder = { Text("my_file.zip") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                // Thread Count Slider (Turbo Speed)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = AppStrings.threadCount(lang),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TurboCyan.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "${threadCount.toInt()} Threads",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TurboCyan
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Slider(
                        value = threadCount,
                        onValueChange = { threadCount = it },
                        valueRange = 1f..16f,
                        steps = 14,
                        colors = SliderDefaults.colors(
                            thumbColor = TurboCyan,
                            activeTrackColor = TurboCyan
                        )
                    )

                    Text(
                        text = AppStrings.threadsDescription(lang, threadCount.toInt()),
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Category Selection Chips
                Text(
                    text = AppStrings.selectCategory(lang),
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(FileCategory.VIDEO, FileCategory.AUDIO, FileCategory.ARCHIVE, FileCategory.DOCUMENT, FileCategory.OTHER).forEach { cat ->
                        val selected = selectedCategory == cat
                        FilterChip(
                            selected = selected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.localizedTitle(lang), fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(cat.icon, contentDescription = null, modifier = Modifier.size(14.dp))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TurboCyan.copy(alpha = 0.25f),
                                selectedLabelColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }

                // Advanced Headers Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdvanced = !showAdvanced }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = AppStrings.customHeaders(lang),
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.primary)
                    )
                    Icon(
                        imageVector = if (showAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                AnimatedVisibility(visible = showAdvanced) {
                    OutlinedTextField(
                        value = customUserAgent,
                        onValueChange = { customUserAgent = it },
                        label = { Text("Custom User-Agent (Optional)") },
                        placeholder = { Text("Mozilla/5.0 ...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (url.isNotBlank()) {
                        viewModel.addDownload(
                            url = url,
                            fileName = fileName,
                            threadCount = threadCount.toInt(),
                            category = selectedCategory,
                            customHeaders = if (customUserAgent.isNotBlank()) "User-Agent: $customUserAgent" else null,
                            startImmediately = true
                        )
                        onDismiss()
                    }
                },
                enabled = url.isNotBlank(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(AppStrings.startDownload(lang))
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(AppStrings.cancel(lang))
                }

                OutlinedButton(
                    onClick = {
                        if (url.isNotBlank()) {
                            viewModel.addDownload(
                                url = url,
                                fileName = fileName,
                                threadCount = threadCount.toInt(),
                                category = selectedCategory,
                                customHeaders = if (customUserAgent.isNotBlank()) "User-Agent: $customUserAgent" else null,
                                startImmediately = false
                            )
                            onDismiss()
                        }
                    },
                    enabled = url.isNotBlank(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(AppStrings.addPaused(lang))
                }
            }
        }
    )
}
