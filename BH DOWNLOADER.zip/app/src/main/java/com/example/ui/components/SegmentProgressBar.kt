package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DownloadChunk
import com.example.ui.theme.SegmentColors

@Composable
fun SegmentProgressBar(
    chunks: List<DownloadChunk>,
    modifier: Modifier = Modifier,
    isDownloading: Boolean = true
) {
    if (chunks.isEmpty()) return

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // Multi-segment track bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            horizontalArrangement = Arrangement.spacedBy(1.5.dp)
        ) {
            val totalBytesSum = chunks.sumOf { it.totalChunkBytes }.coerceAtLeast(1L)

            chunks.forEachIndexed { index, chunk ->
                val weight = if (chunk.totalChunkBytes > 0) {
                    (chunk.totalChunkBytes.toFloat() / totalBytesSum.toFloat()).coerceAtLeast(0.05f)
                } else {
                    1f / chunks.size.toFloat()
                }

                val color = SegmentColors[index % SegmentColors.size]
                val progress = chunk.progress

                Box(
                    modifier = Modifier
                        .weight(weight)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(2.dp))
                        .background(color.copy(alpha = 0.2f))
                ) {
                    // Filled part of this chunk
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress)
                            .fillMaxHeight()
                            .background(
                                color.copy(alpha = if (isDownloading && !chunk.isCompleted) alphaAnim else 1.0f)
                            )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Mini thread status summary row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${chunks.size} Threads (ADM Turbo)",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.primary
            )

            val completedCount = chunks.count { it.isCompleted }
            Text(
                text = "$completedCount / ${chunks.size} Parts Complete",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
