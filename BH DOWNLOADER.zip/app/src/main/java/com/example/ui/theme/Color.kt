package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary High-Tech Palette
val TurboCyan = Color(0xFF00E5FF)
val TurboCyanDark = Color(0xFF00B0FF)
val ElectricIndigo = Color(0xFF6366F1)
val TurboAmber = Color(0xFFF59E0B)
val TurboEmerald = Color(0xFF10B981)
val TurboRose = Color(0xFFF43F5E)

// Dark Theme Surfaces (Deep Cyber Slate)
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF131D31)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Surfaces
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Segment progress colors for ADM-style chunk visualizer
val SegmentColors = listOf(
    Color(0xFF00E5FF), // Cyan
    Color(0xFFF59E0B), // Amber
    Color(0xFF10B981), // Emerald
    Color(0xFF8B5CF6), // Purple
    Color(0xFFEC4899), // Pink
    Color(0xFF3B82F6), // Blue
    Color(0xFFF97316), // Orange
    Color(0xFF14B8A6), // Teal
    Color(0xFFA855F7), // Violet
    Color(0xFFEAB308), // Yellow
    Color(0xFF06B6D4), // Sky
    Color(0xFF84CC16), // Lime
    Color(0xFF6366F1), // Indigo
    Color(0xFFF43F5E), // Rose
    Color(0xFF22C55E), // Green
    Color(0xFF64748B)  // Slate
)
