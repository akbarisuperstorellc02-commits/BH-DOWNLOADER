package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.model.FileCategory
import com.example.ui.MainViewModel
import com.example.ui.theme.TurboAmber
import com.example.ui.theme.TurboCyan
import com.example.ui.theme.TurboEmerald

data class TestDownloadItem(
    val title: String,
    val description: String,
    val sizeLabel: String,
    val url: String,
    val fileName: String,
    val category: FileCategory,
    val icon: ImageVector
)

@Composable
fun BrowserAndTestsScreen(
    viewModel: MainViewModel,
    lang: AppLanguage,
    modifier: Modifier = Modifier
) {
    var webUrlInput by remember { mutableStateOf("") }

    val testFiles = listOf(
        TestDownloadItem(
            title = "10MB Turbo Benchmark Bin",
            description = "High-speed multi-part range benchmark file",
            sizeLabel = "10 MB",
            url = "https://speed.hetzner.de/10MB.bin",
            fileName = "benchmark_10mb.bin",
            category = FileCategory.OTHER,
            icon = Icons.Default.Speed
        ),
        TestDownloadItem(
            title = "25MB Multi-thread Test",
            description = "Ideal for testing 8 to 16 threads and pause/resume",
            sizeLabel = "25 MB",
            url = "https://speed.cloudflare.com/__down?bytes=26214400",
            fileName = "cloudflare_25mb.dat",
            category = FileCategory.OTHER,
            icon = Icons.Default.Bolt
        ),
        TestDownloadItem(
            title = "Sample HD Video (MP4)",
            description = "Big Buck Bunny 720p trailer test video",
            sizeLabel = "5.3 MB",
            url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            fileName = "sample_video_blazes.mp4",
            category = FileCategory.VIDEO,
            icon = Icons.Default.Videocam
        ),
        TestDownloadItem(
            title = "Sample Music Audio (MP3)",
            description = "Creative Commons acoustic soundtrack",
            sizeLabel = "4.2 MB",
            url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            fileName = "sample_soundhelix_song.mp3",
            category = FileCategory.AUDIO,
            icon = Icons.Default.Audiotrack
        ),
        TestDownloadItem(
            title = "Sample PDF Book / Document",
            description = "W3C standard document specification",
            sizeLabel = "1.8 MB",
            url = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
            fileName = "sample_w3c_specification.pdf",
            category = FileCategory.DOCUMENT,
            icon = Icons.Default.Description
        ),
        TestDownloadItem(
            title = "Ultra HD Wallpaper (JPG)",
            description = "Hubble Space high resolution telescope photograph",
            sizeLabel = "8.6 MB",
            url = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop",
            fileName = "space_satellite_4k.jpg",
            category = FileCategory.IMAGE,
            icon = Icons.Default.Image
        ),
        TestDownloadItem(
            title = "Sample Archive (ZIP)",
            description = "Multi-file compressed dataset",
            sizeLabel = "5.1 MB",
            url = "https://github.com/octocat/Hello-World/archive/refs/heads/master.zip",
            fileName = "github_master_archive.zip",
            category = FileCategory.ARCHIVE,
            icon = Icons.Default.Archive
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Quick URL Grabber Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Explore, contentDescription = null, tint = TurboCyan)
                        Text(
                            text = "Web Link Grabber",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = webUrlInput,
                        onValueChange = { webUrlInput = it },
                        placeholder = { Text("https://example.com/download/file...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (webUrlInput.isNotBlank()) {
                                viewModel.openAddDialog(webUrlInput)
                            }
                        },
                        enabled = webUrlInput.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Capture & Download with BH Downloader")
                    }
                }
            }
        }

        // Test Files Header
        item {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Text(
                    text = AppStrings.testFilesHeader(lang),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TurboCyan
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = AppStrings.testFilesSubtitle(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // List of Test Downloads
        items(testFiles) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TurboCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(item.icon, contentDescription = null, tint = TurboCyan, modifier = Modifier.size(22.dp))
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = item.description,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = item.sizeLabel,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = {
                            viewModel.openAddDialog(item.url)
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
