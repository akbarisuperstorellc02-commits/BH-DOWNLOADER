package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.localization.formatBytes
import com.example.localization.formatSpeed
import com.example.ui.theme.TurboAmber
import com.example.ui.theme.TurboCyan
import com.example.ui.theme.TurboEmerald
import com.example.ui.theme.TurboRose
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

@Composable
fun SpeedGraph3D(
    speedHistory: List<Long>,
    currentSpeed: Long,
    peakSpeed: Long,
    averageSpeed: Long,
    activeStreams: Int,
    lang: AppLanguage,
    onTestDemoStream: () -> Unit,
    modifier: Modifier = Modifier
) {
    var is3DMode by remember { mutableStateOf(true) }
    var tiltAngle by remember { mutableFloatStateOf(35f) } // 10° to 60°
    var depthExtrusion by remember { mutableFloatStateOf(38f) } // 10 to 60 dp equivalent

    // Pulse animation for the leading data point & grid scan
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header: Title + Mode Toggle (3D / 2D)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(TurboCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (is3DMode) Icons.Default.ViewInAr else Icons.Default.ShowChart,
                        contentDescription = null,
                        tint = TurboCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column {
                    Text(
                        text = AppStrings.realtimeThroughputTitle(lang),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = if (is3DMode) AppStrings.view3DMode(lang) else AppStrings.view2DMode(lang),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Toggle 3D / 2D Button
            FilterChip(
                selected = is3DMode,
                onClick = { is3DMode = !is3DMode },
                label = { Text(if (is3DMode) "3D" else "2D", fontWeight = FontWeight.Bold) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = TurboCyan.copy(alpha = 0.25f),
                    selectedLabelColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }

        // Key Metrics Dashboard Row (Current, Peak, Avg, Streams)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard(
                label = AppStrings.currentSpeedLabel(lang),
                value = formatSpeed(currentSpeed),
                color = TurboCyan,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = AppStrings.peakSpeedLabel(lang),
                value = formatSpeed(peakSpeed),
                color = TurboAmber,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = AppStrings.averageSpeedLabel(lang),
                value = formatSpeed(averageSpeed),
                color = TurboEmerald,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = AppStrings.activeConnectionsLabel(lang),
                value = "$activeStreams T",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.weight(0.9f)
            )
        }

        // 3D Canvas Visualizer Box with interactive drag tilt
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF070D18))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
                .pointerInput(is3DMode) {
                    if (is3DMode) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            tiltAngle = (tiltAngle - dragAmount.y * 0.15f).coerceIn(12f, 55f)
                            depthExtrusion = (depthExtrusion + dragAmount.x * 0.15f).coerceIn(15f, 65f)
                        }
                    }
                }
        ) {
            val primaryCyan = TurboCyan
            val accentAmber = TurboAmber
            val accentPurple = Color(0xFF8B5CF6)
            val gridColor = Color(0xFF162544)

            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw background cyber matrix grid lines
                drawCyberGrid(
                    w = w,
                    h = h,
                    gridColor = gridColor,
                    is3D = is3DMode,
                    tiltAngle = tiltAngle
                )

                val points = if (speedHistory.size < 2) {
                    listOf(0L, currentSpeed, currentSpeed)
                } else {
                    speedHistory
                }

                val maxVal = max(peakSpeed, max(currentSpeed, 1024L * 100L)).toFloat()

                if (is3DMode) {
                    // Render 3D Perspective Volumetric Ribbon & Depth Faces
                    draw3DVolumetricThroughput(
                        points = points,
                        maxVal = maxVal,
                        w = w,
                        h = h,
                        tiltAngle = tiltAngle,
                        depthOffset = depthExtrusion,
                        frontColor = primaryCyan,
                        depthColor = accentPurple,
                        amberColor = accentAmber,
                        pulseRatio = pulseAnim,
                        glowAlpha = glowAlpha
                    )
                } else {
                    // Render 2D Smooth Gradient Wave with Fill & Glow
                    draw2DSmoothWave(
                        points = points,
                        maxVal = maxVal,
                        w = w,
                        h = h,
                        frontColor = primaryCyan,
                        glowAlpha = glowAlpha,
                        pulseRatio = pulseAnim
                    )
                }
            }

            // HUD badge inside Canvas (Top-Right)
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp),
                shape = RoundedCornerShape(8.dp),
                color = Color(0xAA0B132B)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (currentSpeed > 0) TurboEmerald else TurboAmber)
                    )
                    Text(
                        text = if (currentSpeed > 0) "LIVE STREAM" else "STANDBY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = if (currentSpeed > 0) TurboEmerald else TurboAmber
                        )
                    )
                }
            }

            // Interactive gesture hint overlay
            if (is3DMode) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp),
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0x990F172A)
                ) {
                    Text(
                        text = "Drag to tilt 3D perspective (${tiltAngle.toInt()}°)",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = Color(0xFF94A3B8)),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // 3D Perspective Controls (Sliders for tilt angle & 3D extrusion)
        if (is3DMode) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.tiltControlsLabel(lang),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = "${tiltAngle.toInt()}°",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TurboCyan)
                    )
                }

                Slider(
                    value = tiltAngle,
                    onValueChange = { tiltAngle = it },
                    valueRange = 12f..55f,
                    colors = SliderDefaults.colors(thumbColor = TurboCyan, activeTrackColor = TurboCyan),
                    modifier = Modifier.height(28.dp)
                )
            }
        }

        // Fast Benchmark / Demo Stream Button (if user wants to watch real-time graph live!)
        if (currentSpeed <= 0) {
            Button(
                onClick = onTestDemoStream,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Start Benchmark Test to Watch Live 3D Throughput")
            }
        }
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = color
                ),
                maxLines = 1
            )
        }
    }
}

// -------------------------------------------------------------
// Canvas Drawing Engine for 3D Perspective & Volumetric Ribbons
// -------------------------------------------------------------

private fun DrawScope.drawCyberGrid(
    w: Float,
    h: Float,
    gridColor: Color,
    is3D: Boolean,
    tiltAngle: Float
) {
    val floorY = h * 0.85f

    if (is3D) {
        // Perspective converging depth lines
        val vanishY = h * 0.15f
        val vanishX = w * 0.5f

        val gridCols = 8
        for (i in 0..gridCols) {
            val bottomX = (w / gridCols) * i
            drawLine(
                color = gridColor.copy(alpha = 0.35f),
                start = Offset(vanishX + (bottomX - vanishX) * 0.2f, vanishY + (floorY - vanishY) * 0.2f),
                end = Offset(bottomX, floorY + h * 0.12f),
                strokeWidth = 1f
            )
        }

        // Horizontal perspective floor lines
        val floorLines = 5
        for (i in 1..floorLines) {
            val ratio = (i.toFloat() / floorLines)
            val currentY = floorY - (floorY - vanishY) * (1f - ratio * ratio)
            val spreadFactor = 0.2f + 0.8f * (currentY - vanishY) / (floorY - vanishY)
            val startX = vanishX - (w * 0.5f) * spreadFactor
            val endX = vanishX + (w * 0.5f) * spreadFactor

            drawLine(
                color = gridColor.copy(alpha = 0.25f + 0.15f * ratio),
                start = Offset(startX.coerceAtLeast(0f), currentY),
                end = Offset(endX.coerceAtMost(w), currentY),
                strokeWidth = 1f
            )
        }
    } else {
        // 2D horizontal and vertical grid lines
        val horizontalDivisions = 4
        for (i in 1..horizontalDivisions) {
            val y = (h / (horizontalDivisions + 1)) * i
            drawLine(
                color = gridColor.copy(alpha = 0.4f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }
        val verticalDivisions = 6
        for (i in 1..verticalDivisions) {
            val x = (w / (verticalDivisions + 1)) * i
            drawLine(
                color = gridColor.copy(alpha = 0.3f),
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1f
            )
        }
    }
}

private fun DrawScope.draw3DVolumetricThroughput(
    points: List<Long>,
    maxVal: Float,
    w: Float,
    h: Float,
    tiltAngle: Float,
    depthOffset: Float,
    frontColor: Color,
    depthColor: Color,
    amberColor: Color,
    pulseRatio: Float,
    glowAlpha: Float
) {
    if (points.isEmpty()) return

    val rad = (tiltAngle * PI / 180.0).toFloat()
    val depthX = (cos(rad) * depthOffset * 0.6f)
    val depthY = -(sin(rad) * depthOffset * 0.45f)

    val usableW = w * 0.88f
    val usableH = h * 0.58f
    val baseY = h * 0.82f
    val startX = w * 0.06f

    val stepX = usableW / (points.size - 1).coerceAtLeast(1)

    // Calculate Front 2D and Back Extruded Coordinates
    val frontPoints = mutableListOf<Offset>()
    val backPoints = mutableListOf<Offset>()

    var peakIndex = 0
    var peakValue = 0L

    for (i in points.indices) {
        val speed = points[i]
        if (speed > peakValue) {
            peakValue = speed
            peakIndex = i
        }
        val normalized = (speed.toFloat() / maxVal).coerceIn(0.04f, 1f)
        val fx = startX + i * stepX
        val fy = baseY - normalized * usableH

        val bx = fx + depthX
        val by = fy + depthY

        frontPoints.add(Offset(fx, fy))
        backPoints.add(Offset(bx, by))
    }

    // 1. Draw 3D Base Floor Shadow Projection
    val shadowPath = Path().apply {
        moveTo(frontPoints.first().x, baseY)
        for (p in frontPoints) {
            lineTo(p.x, baseY)
        }
        lineTo(backPoints.last().x, baseY + depthY)
        for (i in backPoints.indices.reversed()) {
            lineTo(backPoints[i].x, baseY + depthY)
        }
        close()
    }
    drawPath(
        path = shadowPath,
        color = Color(0x2200E5FF)
    )

    // 2. Draw Back Wall/Area Extrusion
    val backAreaPath = Path().apply {
        moveTo(backPoints.first().x, baseY + depthY)
        for (p in backPoints) {
            lineTo(p.x, p.y)
        }
        lineTo(backPoints.last().x, baseY + depthY)
        close()
    }
    drawPath(
        path = backAreaPath,
        brush = Brush.verticalGradient(
            colors = listOf(
                depthColor.copy(alpha = 0.35f),
                depthColor.copy(alpha = 0.05f)
            ),
            startY = baseY + depthY - usableH,
            endY = baseY + depthY
        )
    )

    // 3. Draw Connecting Volumetric Facets (Top 3D Ribbon Faces)
    for (i in 0 until frontPoints.size - 1) {
        val f1 = frontPoints[i]
        val f2 = frontPoints[i + 1]
        val b1 = backPoints[i]
        val b2 = backPoints[i + 1]

        val facetPath = Path().apply {
            moveTo(f1.x, f1.y)
            lineTo(f2.x, f2.y)
            lineTo(b2.x, b2.y)
            lineTo(b1.x, b1.y)
            close()
        }

        val facetGradient = Brush.horizontalGradient(
            colors = listOf(
                depthColor.copy(alpha = 0.65f),
                frontColor.copy(alpha = 0.45f)
            ),
            startX = f1.x,
            endX = f2.x
        )
        drawPath(path = facetPath, brush = facetGradient, style = Fill)

        // Draw facet border line for crisp 3D mesh wireframe look
        drawLine(
            color = frontColor.copy(alpha = 0.3f),
            start = f1,
            end = b1,
            strokeWidth = 1f
        )
    }

    // 4. Draw Front Volumetric Area
    val frontAreaPath = Path().apply {
        moveTo(frontPoints.first().x, baseY)
        for (p in frontPoints) {
            lineTo(p.x, p.y)
        }
        lineTo(frontPoints.last().x, baseY)
        close()
    }
    drawPath(
        path = frontAreaPath,
        brush = Brush.verticalGradient(
            colors = listOf(
                frontColor.copy(alpha = 0.45f * glowAlpha),
                Color(0xFF0284C7).copy(alpha = 0.15f),
                Color.Transparent
            ),
            startY = baseY - usableH,
            endY = baseY
        )
    )

    // 5. Draw Glowing Front High-Precision Curve Line
    val frontLinePath = Path().apply {
        moveTo(frontPoints.first().x, frontPoints.first().y)
        for (i in 1 until frontPoints.size) {
            val prev = frontPoints[i - 1]
            val curr = frontPoints[i]
            val cx = (prev.x + curr.x) / 2f
            cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
        }
    }
    // Neon glow halo
    drawPath(
        path = frontLinePath,
        color = frontColor.copy(alpha = 0.4f * glowAlpha),
        style = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
    // Core crisp neon line
    drawPath(
        path = frontLinePath,
        brush = Brush.horizontalGradient(
            colors = listOf(
                Color(0xFF38BDF8),
                frontColor,
                amberColor
            )
        ),
        style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // 6. Draw 3D Peak Floating Marker
    if (peakValue > 0 && peakIndex in frontPoints.indices) {
        val peakPoint = frontPoints[peakIndex]
        val peakBack = backPoints[peakIndex]

        // Vertical laser pointer from peak
        drawLine(
            color = amberColor.copy(alpha = 0.7f),
            start = peakPoint,
            end = Offset(peakPoint.x, baseY),
            strokeWidth = 1.5f,
            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        )

        // Floating diamond at peak
        drawCircle(
            color = amberColor,
            radius = 5f,
            center = peakPoint
        )
        drawCircle(
            color = Color.White,
            radius = 2.5f,
            center = peakPoint
        )
    }

    // 7. Draw Leading Live Head Pulse Radar Ring
    val headPoint = frontPoints.last()
    val pulseRadius = 5f + pulseRatio * 18f
    drawCircle(
        color = frontColor.copy(alpha = (1f - pulseRatio) * 0.8f),
        radius = pulseRadius,
        center = headPoint,
        style = Stroke(width = 2f)
    )
    drawCircle(
        color = frontColor,
        radius = 5f,
        center = headPoint
    )
    drawCircle(
        color = Color.White,
        radius = 2.5f,
        center = headPoint
    )
}

private fun DrawScope.draw2DSmoothWave(
    points: List<Long>,
    maxVal: Float,
    w: Float,
    h: Float,
    frontColor: Color,
    glowAlpha: Float,
    pulseRatio: Float
) {
    val usableW = w * 0.92f
    val usableH = h * 0.65f
    val baseY = h * 0.85f
    val startX = w * 0.04f

    val stepX = usableW / (points.size - 1).coerceAtLeast(1)

    val coords = points.mapIndexed { i, speed ->
        val normalized = (speed.toFloat() / maxVal).coerceIn(0.02f, 1f)
        Offset(startX + i * stepX, baseY - normalized * usableH)
    }

    // Area fill
    val areaPath = Path().apply {
        moveTo(coords.first().x, baseY)
        for (c in coords) {
            lineTo(c.x, c.y)
        }
        lineTo(coords.last().x, baseY)
        close()
    }

    drawPath(
        path = areaPath,
        brush = Brush.verticalGradient(
            colors = listOf(
                frontColor.copy(alpha = 0.5f * glowAlpha),
                Color(0xFF0369A1).copy(alpha = 0.2f),
                Color.Transparent
            ),
            startY = baseY - usableH,
            endY = baseY
        )
    )

    // Smooth spline stroke
    val splinePath = Path().apply {
        moveTo(coords.first().x, coords.first().y)
        for (i in 1 until coords.size) {
            val prev = coords[i - 1]
            val curr = coords[i]
            val cx = (prev.x + curr.x) / 2f
            cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
        }
    }

    drawPath(
        path = splinePath,
        color = frontColor.copy(alpha = 0.35f * glowAlpha),
        style = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    drawPath(
        path = splinePath,
        color = frontColor,
        style = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Leading point
    val head = coords.last()
    drawCircle(
        color = frontColor.copy(alpha = (1f - pulseRatio)),
        radius = 6f + pulseRatio * 16f,
        center = head,
        style = Stroke(width = 2f)
    )
    drawCircle(color = frontColor, radius = 5f, center = head)
    drawCircle(color = Color.White, radius = 2.5f, center = head)
}
