package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.localization.formatSpeed
import com.example.model.DownloadStatus
import com.example.model.DownloadTask
import com.example.model.FileCategory
import com.example.ui.components.AddDownloadDialog
import com.example.ui.components.BrowserAndTestsScreen
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.DownloadCard
import com.example.ui.components.SettingsDialog
import com.example.ui.components.SpeedGraph3D
import com.example.ui.components.TaskDetailsDialog
import com.example.ui.theme.TurboAmber
import com.example.ui.theme.TurboCyan
import com.example.ui.theme.TurboEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val lang by viewModel.language.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val defaultThreads by viewModel.defaultThreads.collectAsState()
    val clipboardEnabled by viewModel.clipboardDetectionEnabled.collectAsState()

    val tasks by viewModel.filteredTasks.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val totalSpeed by viewModel.totalDownloadSpeed.collectAsState()
    val speedHistory by viewModel.speedHistory.collectAsState()
    val peakSpeed by viewModel.peakSpeed.collectAsState()
    val averageSpeed by viewModel.averageSpeed.collectAsState()
    val activeStreams by viewModel.activeStreamsCount.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val clipboardUrl by viewModel.detectedClipboardUrl.collectAsState()

    val isAddOpen by viewModel.isAddDialogOpen.collectAsState()
    val prefilledUrl by viewModel.prefilledUrl.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val detailTask by viewModel.detailTask.collectAsState()

    var taskToDelete by remember { mutableStateOf<DownloadTask?>(null) }
    var showLanguageMenu by remember { mutableStateOf(false) }
    var isSearchExpanded by remember { mutableStateOf(false) }

    // Dynamic RTL/LTR support for Dari, Pashto, Arabic, and English
    CompositionLocalProvider(LocalLayoutDirection provides lang.layoutDirection) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(TurboCyan.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = TurboCyan,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = AppStrings.appName(lang),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            fontSize = 17.sp
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = TurboCyan.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "ADM PRO",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp,
                                                color = TurboCyan
                                            ),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }

                                if (totalSpeed > 0) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = TurboCyan.copy(alpha = 0.15f),
                                        modifier = Modifier.clickable { viewModel.selectTab(4) }
                                    ) {
                                        Text(
                                            text = "⚡ ${formatSpeed(totalSpeed)} (3D)",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = TurboCyan,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    actions = {
                        // Search Button
                        IconButton(onClick = { isSearchExpanded = !isSearchExpanded }) {
                            Icon(
                                imageVector = if (isSearchExpanded) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "Search",
                                tint = if (isSearchExpanded) TurboCyan else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Theme Toggle Button
                        IconButton(onClick = {
                            val next = if (themeMode == "dark") "light" else "dark"
                            viewModel.setThemeMode(next)
                        }) {
                            Icon(
                                imageVector = if (themeMode == "dark") Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Theme",
                                tint = TurboAmber
                            )
                        }

                        // Language Selector Menu
                        Box {
                            IconButton(onClick = { showLanguageMenu = true }) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            DropdownMenu(
                                expanded = showLanguageMenu,
                                onDismissRequest = { showLanguageMenu = false }
                            ) {
                                AppLanguage.values().forEach { l ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(l.nativeName, fontWeight = if (l == lang) FontWeight.Bold else FontWeight.Normal)
                                                if (l == lang) {
                                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = TurboCyan, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        },
                                        onClick = {
                                            showLanguageMenu = false
                                            viewModel.setLanguage(l)
                                        }
                                    )
                                }
                            }
                        }

                        // Settings Button
                        IconButton(onClick = { viewModel.openSettings() }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { viewModel.openAddDialog() },
                    containerColor = TurboCyan,
                    contentColor = Color(0xFF00363D),
                    shape = RoundedCornerShape(16.dp),
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text(AppStrings.addDownload(lang), fontWeight = FontWeight.Bold) }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Search bar (if expanded)
                AnimatedVisibility(visible = isSearchExpanded) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("Search by name or URL...") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear")
                                    }
                                }
                            }
                        )
                    }
                }

                // Clipboard Link Detection Banner
                AnimatedVisibility(
                    visible = clipboardUrl != null,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = TurboCyan.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = TurboCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.clipboardFoundTitle(lang),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = TurboCyan)
                                )
                                Text(
                                    text = clipboardUrl ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { viewModel.acceptClipboardPrompt() }) {
                                Icon(Icons.Default.FileDownload, contentDescription = "Download", tint = TurboCyan)
                            }
                            IconButton(onClick = { viewModel.dismissClipboardPrompt() }) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // Main Navigation Tabs (All, Downloading, Completed, Categories, 3D Speed Graph, Browser/Tests)
                val tabs = listOf(
                    AppStrings.tabAll(lang),
                    AppStrings.tabDownloading(lang),
                    AppStrings.tabCompleted(lang),
                    AppStrings.tabCategories(lang),
                    AppStrings.tabThroughput(lang),
                    AppStrings.tabBrowser(lang)
                )

                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = TurboCyan,
                    indicator = { tabPositions ->
                        if (selectedTab < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = TurboCyan,
                                height = 3.dp
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        val count = when (index) {
                            0 -> allTasks.size
                            1 -> allTasks.count { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
                            2 -> allTasks.count { it.status == DownloadStatus.COMPLETED }
                            4 -> if (totalSpeed > 0) 1 else null
                            else -> null
                        }

                        Tab(
                            selected = selectedTab == index,
                            onClick = { viewModel.selectTab(index) },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = title,
                                        fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTab == index) TurboCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (count != null && count > 0) {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (selectedTab == index) TurboCyan else MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = "$count",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (selectedTab == index) Color(0xFF00363D) else MaterialTheme.colorScheme.onSurfaceVariant
                                                ),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        )
                    }
                }

                // Sub-Bar: Batch Actions & Categories Filter
                if (selectedTab == 3) {
                    // Category Chips Bar
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(FileCategory.values()) { cat ->
                            val isSelected = selectedCategory == cat
                            val count = if (cat == FileCategory.ALL) allTasks.size else allTasks.count { it.category == cat }
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectCategory(cat) },
                                label = { Text("${cat.localizedTitle(lang)} ($count)", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(cat.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TurboCyan.copy(alpha = 0.25f),
                                    selectedLabelColor = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                } else if (selectedTab != 4 && selectedTab != 5 && allTasks.isNotEmpty()) {
                    // Quick Batch Action Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val hasDownloading = allTasks.any { it.status == DownloadStatus.DOWNLOADING }
                        val hasPaused = allTasks.any { it.status == DownloadStatus.PAUSED }
                        val hasCompleted = allTasks.any { it.status == DownloadStatus.COMPLETED }

                        if (hasDownloading) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { viewModel.pauseAll() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(14.dp), tint = TurboAmber)
                                    Text(AppStrings.pauseAll(lang), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        if (hasPaused) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { viewModel.resumeAll() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp), tint = TurboCyan)
                                    Text(AppStrings.resumeAll(lang), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        if (hasCompleted) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { viewModel.clearCompleted() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.ClearAll, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(AppStrings.clearCompleted(lang), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }

                // Main Content View
                when (selectedTab) {
                    4 -> {
                        // 3D Speed Graph screen
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                SpeedGraph3D(
                                    speedHistory = speedHistory,
                                    currentSpeed = totalSpeed,
                                    peakSpeed = peakSpeed,
                                    averageSpeed = averageSpeed,
                                    activeStreams = activeStreams,
                                    lang = lang,
                                    onTestDemoStream = { viewModel.startDemoStream() }
                                )
                            }

                            val activeTasks = allTasks.filter { it.status == DownloadStatus.DOWNLOADING }
                            if (activeTasks.isNotEmpty()) {
                                item {
                                    Text(
                                        text = AppStrings.tabDownloading(lang),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TurboCyan)
                                    )
                                }
                                items(activeTasks, key = { it.id }) { task ->
                                    DownloadCard(
                                        task = task,
                                        viewModel = viewModel,
                                        lang = lang,
                                        onShowDeleteDialog = { taskToDelete = it }
                                    )
                                }
                            }
                            item {
                                Spacer(modifier = Modifier.height(80.dp))
                            }
                        }
                    }
                    5 -> {
                        // Browser & Test Benchmark Screen
                        BrowserAndTestsScreen(
                            viewModel = viewModel,
                            lang = lang
                        )
                    }
                    else -> {
                        // Downloads List or Empty State
                        if (tasks.isEmpty()) {
                            EmptyDownloadsState(
                                lang = lang,
                                onTryTestDownload = { viewModel.selectTab(5) }
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // If on "Downloading" tab and there are active downloads, show the 3D speed graph at the top!
                                if (selectedTab == 1 && allTasks.any { it.status == DownloadStatus.DOWNLOADING }) {
                                    item {
                                        SpeedGraph3D(
                                            speedHistory = speedHistory,
                                            currentSpeed = totalSpeed,
                                            peakSpeed = peakSpeed,
                                            averageSpeed = averageSpeed,
                                            activeStreams = activeStreams,
                                            lang = lang,
                                            onTestDemoStream = { viewModel.startDemoStream() },
                                            modifier = Modifier.padding(bottom = 6.dp)
                                        )
                                    }
                                }

                                items(tasks, key = { it.id }) { task ->
                                    DownloadCard(
                                        task = task,
                                        viewModel = viewModel,
                                        lang = lang,
                                        onShowDeleteDialog = { taskToDelete = it }
                                    )
                                }
                                item {
                                    Spacer(modifier = Modifier.height(80.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialogs
        if (isAddOpen) {
            AddDownloadDialog(
                initialUrl = prefilledUrl,
                viewModel = viewModel,
                lang = lang,
                defaultThreads = defaultThreads,
                onDismiss = { viewModel.closeAddDialog() }
            )
        }

        if (detailTask != null) {
            TaskDetailsDialog(
                task = detailTask!!,
                viewModel = viewModel,
                lang = lang,
                onDismiss = { viewModel.closeDetails() }
            )
        }

        if (isSettingsOpen) {
            SettingsDialog(
                viewModel = viewModel,
                lang = lang,
                currentTheme = themeMode,
                defaultThreads = defaultThreads,
                clipboardEnabled = clipboardEnabled,
                onDismiss = { viewModel.closeSettings() }
            )
        }

        if (taskToDelete != null) {
            DeleteConfirmDialog(
                task = taskToDelete!!,
                lang = lang,
                onConfirm = { deleteFromDisk ->
                    viewModel.cancelOrDeleteDownload(taskToDelete!!.id, deleteFromDisk)
                    taskToDelete = null
                },
                onDismiss = { taskToDelete = null }
            )
        }
    }
}

@Composable
fun EmptyDownloadsState(
    lang: AppLanguage,
    onTryTestDownload: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(TurboCyan.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.FileDownload,
                contentDescription = null,
                tint = TurboCyan,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = AppStrings.emptyStateTitle(lang),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = AppStrings.emptyStateSubtitle(lang),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = TurboCyan.copy(alpha = 0.15f),
            modifier = Modifier.clickable { onTryTestDownload() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Speed, contentDescription = null, tint = TurboCyan, modifier = Modifier.size(20.dp))
                Text(
                    text = AppStrings.testFilesHeader(lang),
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TurboCyan
                    )
                )
            }
        }
    }
}
